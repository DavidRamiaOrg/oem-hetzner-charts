{{/*
  Jobs that read the RDS master credentials from their environment start after the
  ExternalSecret (wave 1) has merged them into odoo-admin-secrets; with a Job at
  wave 0 ArgoCD would wait for it and never apply the ExternalSecret. Nothing is
  rendered without a MasterSecret.
*/}}
{{/* Credentials sealed for the cluster's Sealed Secrets controller (02-SealedSecrets.yaml). */}}
{{- define "odoo.sealed" -}}
{{- if eq (toString .Values.Sealed.Enabled) "true" }}true{{ end -}}
{{- end -}}

{{- define "odoo.sshKeysSecret" -}}
{{- if include "odoo.sealed" . }}ssh-keys-sealed{{ else }}ssh-keys{{ end -}}
{{- end -}}

{{- define "odoo.pgSuperuserSecret" -}}
{{- if include "odoo.sealed" . }}odoo-pg-superuser-sealed{{ else }}odoo-pg-superuser{{ end -}}
{{- end -}}

{{- define "odoo.adminSecretsWave" -}}
{{- if or .Values.Postgres.MasterSecret.Name .Values.Source.MasterSecret.Name -}}
annotations:
  argocd.argoproj.io/sync-wave: "2"
{{- end -}}
{{- end -}}

{{/*
  Common labels applied to every resource of the instance. Driven entirely by
  the OEM-supplied `Labels` parameter (a YAML map serialised like Git.Keys);
  add/remove labels in OEM only — this helper ranges over whatever is sent.
  Empty / unset → emits nothing.
*/}}
{{- define "odoo.commonLabels" -}}
{{- with (fromYaml (.Values.Labels | default "")) -}}
{{- toYaml . -}}
{{- end -}}
{{- end -}}

{{/*
  Deterministic SELinux MCS level derived from the Release namespace.

  Returns two MCS categories in the 0-1023 range so all pods in the same
  namespace share the same level (can access the same PVCs) while different
  namespaces get different levels (MCS isolation between tenants).

  MCS category range is 0..1023 (s0:c0..c1023).
*/}}
{{- define "odoo.mcsLevel" -}}
{{- $ns := .Release.Namespace -}}
{{- $a := mod (int (adler32sum $ns)) 1024 -}}
{{- $b := mod (int (adler32sum (printf "mcs-salt-%s" $ns))) 1024 -}}
{{- if eq $a $b -}}
{{- $b = mod (add $b 1) 1024 -}}
{{- end -}}
{{- $lo := min $a $b -}}
{{- $hi := max $a $b -}}
s0:c{{ $lo }},c{{ $hi }}
{{- end -}}

{{/*
  Shared pod-level securityContext for Odoo workloads.

  Combines:
    - fsGroup / fsGroupChangePolicy (POSIX ownership of mounted volumes)
    - seLinuxOptions.level (deterministic MCS level per namespace so pods
      sharing the odoo-base PVC see consistent SELinux labels across restarts)

  Usage:
      {{- include "odoo.podSecurityContext" . | nindent 6 }}
*/}}
{{/*
  odoo.fsGroup — el gid del usuario `odoo` de la imagen.

  Un solo sitio porque lo consumen DOS mecanismos distintos que tienen que
  coincidir: el `fsGroup` del pod (aqui debajo) y el volumeAttribute `fsGroup`
  del volumen de fuentes OCI (providers/_common.tpl). Ese segundo existe porque
  el CSIDriver de csi-loop declara `fsGroupPolicy: None`, o sea que kubelet NO
  aplica el primero a ese volumen y el driver tiene que hacerlo el mismo. Si los
  dos numeros divergieran, la raiz de /home/odoo/src dejaria de ser escribible
  por el tenant sin que nada lo avise.
*/}}
{{- define "odoo.fsGroup" -}}999{{- end -}}

{{- define "odoo.podSecurityContext" -}}
securityContext:
  fsGroup: {{ include "odoo.fsGroup" . }}
  fsGroupChangePolicy: OnRootMismatch
  seLinuxOptions:
    level: {{ include "odoo.mcsLevel" . | quote }}
{{- end -}}

{{/*
  Name of the PVC backing /home/odoo for the running pods.

  - Storage.Type=network → `odoo-data-efs` (eks) / `odoo-data-network` (generic)
  - Storage.Type=fsx → `odoo-data-fsx`
  - Storage.Type=block → `odoo-base` (historical name kept for backwards
                        compatibility with existing instances).

  Different names per backend keep the PVCs side-by-side so an instance
  that migrates between storage types doesn't see the new claim collide
  with an old PVC bound to a different backend.

  Used by 04-Storage.yaml for the PVC's `metadata.name` (and the static
  PV `claimRef.name` + `volumeName` on FSx) and by `odoo.volumes` for
  each pod's `volumes[].persistentVolumeClaim.claimName`. The pod's
  internal volume name stays `odoo-base` everywhere — it's a spec-local
  reference, not the PVC name.
*/}}
{{/*
  Backend infix for the `network` storage type: `efs` on AWS (eks), where the
  backend really is EFS, and `network` on any other provider (generic), where it
  is not. Keeps AWS names (odoo-data-efs, sc-<ns>-efs) stable while generic uses
  neutral names (odoo-data-network, sc-<ns>-network).
*/}}
{{- define "odoo.networkBackend" -}}
{{- if eq .Values.K8S.Provider "eks" -}}efs{{- else -}}network{{- end -}}
{{- end -}}

{{- define "odoo.odooBaseClaimName" -}}
{{- if eq .Values.Storage.Type "network" -}}odoo-data-{{ include "odoo.networkBackend" . }}
{{- else if eq .Values.Storage.Type "fsx" -}}odoo-data-fsx
{{- else -}}odoo-base
{{- end -}}
{{- end -}}

{{/*
  initContainers wrapper: emite el bloque `initContainers:` con el
  mount-manager (native sidecar) cuando `Storage.Type=network`. En cualquier
  otro caso, no se emite nada.

  Usage en spec del Pod template:
    {{- include "odoo.initContainers" . | nindent 6 }}

  Storage.Type=network ya no requiere init containers: el driver csi-loop
  hace los mounts cluster-wide vía CSI estándar. Storage.Type=block/fsx
  tampoco — los mounts los hace kubelet. Mantenemos el helper por si
  se necesita inyectar init containers futuros sin tocar 10-Odoo et al.
*/}}
{{- define "odoo.initContainers" -}}
{{- end -}}

{{/*
Token del ServiceAccount `oem-events`, para publicar StatusEvents contra el
apiserver.

Se proyecta A MANO en vez de dejar que el kubelet lo automonte, y por un motivo
concreto: el automontaje lo pone en TODOS los contenedores del pod, incluido
`odoo`, que ejecuta codigo del cliente. Con `automountServiceAccountToken: false`
en la ServiceAccount y este volumen montado solo donde se emite, el contenedor
del cliente se queda sin ninguna credencial de apiserver — hoy si la tiene (la
del SA `default`, sin permisos).

`expirationSeconds` corto a proposito: el kubelet lo rota en disco y el cliente
lo relee en cada peticion, asi que un token caducado en memoria no existe.
*/}}
{{- define "odoo.volume.eventsToken" -}}
{{- if eq .Values.Instance.Controller "oem" }}
- name: oem-events-token
  projected:
    defaultMode: 0444
    sources:
      - serviceAccountToken:
          path: token
          expirationSeconds: 3600
      - configMap:
          name: kube-root-ca.crt
          items:
            - key: ca.crt
              path: ca.crt
      - downwardAPI:
          items:
            - path: namespace
              fieldRef:
                fieldPath: metadata.namespace
{{- end }}
{{- end -}}

{{/* Montaje del token anterior. Solo en contenedores que publican eventos. */}}
{{- define "odoo.volumeMount.eventsToken" -}}
{{- if eq .Values.Instance.Controller "oem" }}
- name: oem-events-token
  mountPath: /var/run/secrets/oem-events
  readOnly: true
{{- end }}
{{- end -}}

{{/*
El namespace del pod en la ruta donde el runtime lo espera, SIN token.

Hace falta porque `metrics-server` lo lee de
/var/run/secrets/kubernetes.io/serviceaccount/namespace, y al desactivar el
automontaje para dejar al contenedor `odoo` sin credencial esa ruta desaparece.
No falla —cae a la cadena "local"— pero etiquetaria todas las metricas con un
namespace falso, que es peor que un error: se ve sano y miente.
*/}}
{{- define "odoo.volume.k8sNamespace" -}}
{{- if eq .Values.Instance.Controller "oem" }}
- name: k8s-namespace
  downwardAPI:
    items:
      - path: namespace
        fieldRef:
          fieldPath: metadata.namespace
{{- end }}
{{- end -}}

{{- define "odoo.volumeMount.k8sNamespace" -}}
{{- if eq .Values.Instance.Controller "oem" }}
- name: k8s-namespace
  mountPath: /var/run/secrets/kubernetes.io/serviceaccount
  readOnly: true
{{- end }}
{{- end -}}
