{{- define "odoo.provider.eks.s3PVDefinition" }}
storageClassName: s3-csi
mountOptions:
  - allow-delete
  - allow-overwrite
  - allow-other
  - region {{ .Values.K8S.Region }}
  - uid=999
  - gid=999
  # mountpoint-s3 multipart upload caps a single file at
  # `write-part-size × 10000 parts`. Default is 5-16 MiB depending on the
  # bundled mountpoint-s3 version → ceiling ~50-160 GiB, AND tar / gzip
  # hit EFBIG well below that because of internal mountpoint-s3 buffer
  # pressure (observed: backups truncating at ~30 GiB). Bumping to 64 MiB
  # raises the theoretical ceiling to ~640 GiB and clears the buffer
  # pressure that caused tar to fail mid-write. Memory cost: ~64 MiB ×
  # outstanding parts per open file (negligible in our use case — one
  # backup tar.gz at a time).
  - write-part-size 67108864
csi:
  driver: s3.csi.aws.com
  volumeHandle: s3-csi-driver-volume
  volumeAttributes:
    bucketName: "{{ .Values.K8S.Bucket }}"
{{- end }}

{{- define "odoo.provider.eks.s3PVCDefinition" }}
storageClassName: s3-csi
{{- end }}

{{/*
  EFS Access Point dynamic provisioning con PosixUser=999.

  Razón de aceptar el uid forzado: K8s subPath + mountPropagation son
  incompatibles (subPath bind = MS_PRIVATE) → mount-manager no podía
  propagar su loop a los otros containers. Sin subPath, necesitamos
  isolation kernel-level vía AP. El driver requiere PosixUser → forzamos
  999 (= odoo).

  Trade-off: login-server's "chown root + chmod 600" sobre tokens NO
  funciona en EFS (AP rechaza chown a 0). Tokens quedan owned 999 mode
  preservado. Boundary root-only no se enforce en EFS — solo en EBS.
*/}}
{{- define "odoo.provider.eks.scDefinitionEfs" }}
provisioner: efs.csi.aws.com
parameters:
  provisioningMode: efs-ap
  fileSystemId: "{{ required "Storage.Network.Filesystem is required when Storage.Type=network or MigrateStorage=network" .Values.Storage.Network.Filesystem }}"
  basePath: "/dynamic_provisioning"
  subPathPattern: "${.PV.name}"
  ensureUniqueDirectory: "true"
  reuseAccessPoint: "false"
  directoryPerms: "770"
  uid: "999"
  gid: "999"
reclaimPolicy: Delete
volumeBindingMode: Immediate
{{- end }}

{{- define "odoo.provider.eks.scDefinition" }}
{{- if eq .Values.Storage.Type "network" }}
{{ include "odoo.provider.eks.scDefinitionEfs" . }}
{{- else }}
provisioner: ebs.csi.aws.com
parameters:
  encrypted: "true"
  fsType: ext4
  tagSpecification_1: "Client_ID={{ .Values.Customer.ID }}"
  type: gp3
reclaimPolicy: Delete
allowVolumeExpansion: true
volumeBindingMode: Immediate
allowedTopologies:
  - matchLabelExpressions:
      - key: topology.kubernetes.io/zone
        values:
          - "{{ .Values.K8S.Region }}a"
{{- end }}
{{- end }}

{{- /*
  SC para los volumenes del Cluster CloudNativePG (PGDATA + WAL). Mismos parametros
  que la de arriba —y ese es el motivo de existir: son los que llevan el tag
  `Client_ID`, sin el cual los EBS del Cluster no se imputan a ningun cliente— pero
  con DOS diferencias deliberadas:

  🔴 SIN `allowedTopologies`. La del tenant clava la zona en `<region>a` porque ahi
  vive su RDS y el pod es uno solo; un Cluster son DOS instancias, y atarlas a la
  misma AZ deja la replica sin cubrir lo unico que no cubre el nodo: perder la zona.

  🔑 `WaitForFirstConsumer` en vez de `Immediate`, que es lo que hace posible lo
  anterior: el volumen nace en la AZ del nodo que el scheduler ya ha elegido, asi
  que manda la anti-afinidad del Cluster y no el orden de creacion de los discos.
  Es tambien el binding del `gp3` por defecto sobre el que corren hoy.
*/ -}}
{{- define "odoo.provider.eks.scDefinitionCnpg" }}
provisioner: ebs.csi.aws.com
parameters:
  encrypted: "true"
  fsType: ext4
  tagSpecification_1: "Client_ID={{ .Values.Customer.ID }}"
  tagSpecification_2: "Namespace={{ .Release.Namespace }}"
  tagSpecification_3: "Backup=true"
  type: gp3
reclaimPolicy: Delete
allowVolumeExpansion: true
volumeBindingMode: WaitForFirstConsumer
{{- end }}

{{- define "odoo.provider.eks.snapshotDefinition" }}
driver: ebs.csi.aws.com
parameters:
  tagSpecification_1: "Client_ID={{ .Values.Customer.ID }}"
  tagSpecification_2: "Namespace={{ .Release.Namespace }}"
{{- end }}

{{- /* Los health checks de un Service los configura el aws-load-balancer-controller
       sobre el target group que crea para el Ingress que apunta a ese Service. Bajo
       CloudFront + Traefik no hay target group ninguno: quien decide si el backend
       esta vivo es la readinessProbe del pod (Traefik solo enruta a endpoints Ready).
       Cada bloque se condiciona a la clase de SU PROPIO Ingress — el de jupyter no
       depende de que odoo se haya movido a Traefik. Mismo criterio que las anotaciones
       de los Ingress, mas abajo.

       NO se toca el caso "OEM sin Ingress de jupyter": ahi estas tres anotaciones
       llevan siendo inertes desde siempre (el Ingress de jupyter solo se renderiza en self
       mode) y limpiarlo cambiaria el YAML de ~150 tenants que no migran a nada, que es
       justo lo que esta ronda no quiere hacer. */}}
{{- define "odoo.provider.eks.jupyterServiceAnnotations" }}
{{- if not (include "odoo.ingress.cloudfrontTraefik.jupyter" .) }}
annotations:
  alb.ingress.kubernetes.io/healthcheck-path: "/login"
  alb.ingress.kubernetes.io/healthcheck-interval-seconds: "5"
  alb.ingress.kubernetes.io/healthcheck-timeout-seconds: "2"
{{- end }}
{{- end }}

{{- define "odoo.provider.eks.nginxServiceAnnotations" }}
{{- if not (include "odoo.ingress.cloudfrontTraefik" .) }}
annotations:
  alb.ingress.kubernetes.io/healthcheck-path: "/health_check"
  alb.ingress.kubernetes.io/healthcheck-interval-seconds: "5"
  alb.ingress.kubernetes.io/healthcheck-timeout-seconds: "2"
{{- end }}
{{- end }}

{{- /* Anotacion de GRUPO: los Ingress de odoo y de dominios custom comparten group.name,
       asi que tienen que emitir el MISMO valor o el controller rechaza el grupo. */}}
{{- define "odoo.provider.eks.wafAnnotation" -}}
{{- with .Values.K8S.WafAclArn }}
  alb.ingress.kubernetes.io/wafv2-acl-arn: "{{ . }}"
{{- end }}
{{- end }}

{{- /* Las anotaciones `alb.*` sólo las lee el aws-load-balancer-controller. Con
       `Ingress.Odoo.Type=traefik` (CloudFront multi-tenant → NLB → Traefik) no hay
       ALB al que apliquen: son inertes, pero documentan un routing que ya no existe
       y quien las lea creerá que este tenant vive en `Ingress.Odoo.Name`. Se emiten
       sólo cuando el Ingress lo sirve el ALB — que sigue siendo el caso de casi
       todos los tenants. Ver `odoo.ingress.cloudfrontTraefik` en _common.tpl. */}}
{{- define "odoo.provider.eks.odooIngressAnnotations" }}
{{- if not (include "odoo.ingress.cloudfrontTraefik" .) }}
annotations:
  alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
  alb.ingress.kubernetes.io/load-balancer-name: "{{ .Values.Ingress.Odoo.Name }}"
  alb.ingress.kubernetes.io/group.name: "{{ .Values.Ingress.Odoo.Name }}"
  alb.ingress.kubernetes.io/group.order: "200"
  alb.ingress.kubernetes.io/scheme: internet-facing
  alb.ingress.kubernetes.io/ssl-redirect: "443"
  alb.ingress.kubernetes.io/load-balancer-attributes: idle_timeout.timeout_seconds=900
  alb.ingress.kubernetes.io/target-type: ip
{{- include "odoo.provider.eks.wafAnnotation" . }}
{{- end }}
{{- end }}


{{- /* Mismo criterio que odooIngressAnnotations: nada de `alb.*` bajo Traefik. */}}
{{- define "odoo.provider.eks.customIngressAnnotations" }}
{{- if not (include "odoo.ingress.cloudfrontTraefik" .) }}
annotations:
  alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
  alb.ingress.kubernetes.io/load-balancer-name: "{{ .Values.Ingress.Odoo.Name }}"
  alb.ingress.kubernetes.io/group.name: "{{ .Values.Ingress.Odoo.Name }}"
  alb.ingress.kubernetes.io/group.order: "200"
  alb.ingress.kubernetes.io/scheme: internet-facing
  alb.ingress.kubernetes.io/ssl-redirect: "443"
  alb.ingress.kubernetes.io/load-balancer-attributes: idle_timeout.timeout_seconds=900
  alb.ingress.kubernetes.io/target-type: ip
{{- include "odoo.provider.eks.wafAnnotation" . }}
{{- end }}
{{- end }}

{{- /* El Ingress de jupyter (self mode) va por su propia clase, `Ingress.Jupyter.Type`,
       y no entra en la migración a CloudFront: aquí no se toca nada. */}}
{{- define "odoo.provider.eks.jupyterIngressAnnotations" }}
annotations:
  alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
  alb.ingress.kubernetes.io/load-balancer-name: "{{ .Values.Ingress.Jupyter.Name }}"
  alb.ingress.kubernetes.io/group.name: "{{ .Values.Ingress.Jupyter.Name }}"
  alb.ingress.kubernetes.io/group.order: "200"
  alb.ingress.kubernetes.io/scheme: internet-facing
  alb.ingress.kubernetes.io/ssl-redirect: "443"
  alb.ingress.kubernetes.io/target-type: ip
  alb.ingress.kubernetes.io/inbound-cidrs: "94.24.112.224/28"
{{- end }}
