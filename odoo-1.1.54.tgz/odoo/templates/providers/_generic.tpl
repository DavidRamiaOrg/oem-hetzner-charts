{{/*
  Generic provider (K8S.Provider=k8s): storage + ingress parametrised ENTIRELY
  from values, so a plain Kubernetes cluster needs no bespoke _<cloud>.tpl — just
  values. It implements the same helper contract as _eks.tpl.

  Everything cloud-specific is a value:
    K8S.ObjectStorage   the S3 PV/PVC of the backups volume (CSI driver + attrs)
    K8S.BlockStorage    the StorageClass of the tenant / CNPG disks (provisioner + params)
    K8S.Snapshot        the VolumeSnapshotClass driver (+ params); empty driver = none
    K8S.IngressAnnotations / K8S.ServiceAnnotations   maps emitted as annotations

  The per-tenant dynamic bits (bucket, Client_ID, namespace, region) are NOT fixed
  here: a value may contain a template string like '{{`{{ .Values.K8S.Bucket }}`}}'
  and it is evaluated with `tpl`. So the same template serves AWS, Hetzner or any
  other cluster — only the values differ. The chart ships Hetzner (hcloud) defaults.

  Note vs a hand-written _<cloud>.tpl: `toYaml` sorts map keys and may quote
  scalars, so a map (volumeAttributes, annotations, parameters) can come out in a
  different key order / quoting than a hand-ordered template. That is
  YAML-equivalent — Kubernetes stores maps normalised — so the objects are the
  same; it is not meant to be byte-identical to a hand-written per-cloud template.
*/}}

{{- define "odoo.provider.k8s.s3PVDefinition" }}
storageClassName: {{ .Values.K8S.ObjectStorage.StorageClassName }}
{{- with .Values.K8S.ObjectStorage.MountOptions }}
mountOptions:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
csi:
  driver: {{ .Values.K8S.ObjectStorage.Driver }}
  volumeHandle: {{ tpl .Values.K8S.ObjectStorage.VolumeHandle $ }}
  volumeAttributes:
{{ tpl (toYaml .Values.K8S.ObjectStorage.VolumeAttributes) $ | indent 4 }}
{{- range .Values.K8S.ObjectStorage.SecretRefs }}
  {{ .kind }}:
    name: {{ .name }}
    namespace: {{ .namespace }}
{{- end }}
{{- end }}

{{- define "odoo.provider.k8s.s3PVCDefinition" }}
storageClassName: {{ .Values.K8S.ObjectStorage.StorageClassName }}
{{- end }}

{{- /* StorageClass of the tenant disk. The CNPG one (06-Postgres) differs only in
       the binding mode (see _eks for why), so the only line that changes between
       the two defines is volumeBindingMode. */ -}}
{{- define "odoo.provider.k8s.scDefinition" }}
provisioner: {{ .Values.K8S.BlockStorage.Provisioner }}
{{- with .Values.K8S.BlockStorage.Parameters }}
parameters:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
reclaimPolicy: {{ .Values.K8S.BlockStorage.ReclaimPolicy }}
allowVolumeExpansion: {{ .Values.K8S.BlockStorage.AllowVolumeExpansion }}
volumeBindingMode: {{ .Values.K8S.BlockStorage.VolumeBindingMode }}
{{- with .Values.K8S.BlockStorage.AllowedTopologies }}
allowedTopologies:
{{ tpl (toYaml .) $ | indent 0 }}
{{- end }}
{{- end }}

{{- define "odoo.provider.k8s.scDefinitionCnpg" }}
provisioner: {{ .Values.K8S.BlockStorage.Provisioner }}
{{- with .Values.K8S.BlockStorage.Parameters }}
parameters:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
reclaimPolicy: {{ .Values.K8S.BlockStorage.ReclaimPolicy }}
allowVolumeExpansion: {{ .Values.K8S.BlockStorage.AllowVolumeExpansion }}
volumeBindingMode: {{ .Values.K8S.BlockStorage.CnpgVolumeBindingMode }}
{{- with .Values.K8S.BlockStorage.AllowedTopologies }}
allowedTopologies:
{{ tpl (toYaml .) $ | indent 0 }}
{{- end }}
{{- end }}

{{- define "odoo.provider.k8s.snapshotDefinition" }}
driver: {{ .Values.K8S.Snapshot.Driver }}
{{- with .Values.K8S.Snapshot.Parameters }}
parameters:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
{{- end }}

{{- define "odoo.provider.k8s.nginxServiceAnnotations" }}
{{- with .Values.K8S.ServiceAnnotations }}
annotations:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
{{- end }}

{{- define "odoo.provider.k8s.jupyterServiceAnnotations" }}
{{- with .Values.K8S.ServiceAnnotations }}
annotations:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
{{- end }}

{{- define "odoo.provider.k8s.odooIngressAnnotations" }}
{{- with .Values.K8S.IngressAnnotations }}
annotations:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
{{- end }}

{{- define "odoo.provider.k8s.customIngressAnnotations" }}
{{- with .Values.K8S.IngressAnnotations }}
annotations:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
{{- end }}

{{- define "odoo.provider.k8s.jupyterIngressAnnotations" }}
{{- with .Values.K8S.IngressAnnotations }}
annotations:
{{ tpl (toYaml .) $ | indent 2 }}
{{- end }}
{{- end }}
