{{/*
  Common helpers (provider-agnostic)
*/}}

{{- define "odoo.imageRegistryCredentials" }}
{{- if and (and .Values.Images.Credentials.Host .Values.Images.Credentials.User) .Values.Images.Credentials.Password }}
imagePullSecrets:
- name: registry-credentials
{{- end }}
{{- end }}

{{/*
  Primary node-selector: pega todos los pods primary (writer/base/cron/nginx
  primary) al mismo nodo del node group `K8S.Node` vía podAffinity
  preferred (weight=100). El scheduler intenta clumpearlos en el mismo
  hostname siempre que sea posible.

  HISTORIA: antes usábamos podAffinity required, pero generaba
  chicken-egg en el caso degraded — si TODOS los pods primary morían
  simultáneamente (eviction masiva, nodo terminado, rolling de MNG),
  ningún pod nuevo podía schedule porque la regla pedía que YA
  existiera otro pod con label `node=<K8S.Node>` en algún hostname.
  Incidente real 22-may 2026 en cluster odoo-production tras rolling
  MNG (PR #1123): pods evicted → primary pods Pending por podAffinity
  required → ~12 min de HTTP 503 en Odoo PC. Mitigación de emergencia:
  kubectl patch para eliminar podAffinity. Solución permanente: pasar
  a preferred (cambio 100% backward-compatible en operación normal —
  preferred weight=100 sigue clumpeando agresivamente cuando hay pods
  vivos con el label, pero permite arrancar desde cero cuando no los
  hay).

  Sólo lo usan los pods primary. Las réplicas extras (13-OdooReader,
  14-NginxReader) usan `odoo.nodeSelector.spread` para poder distribuirse.
*/}}
{{- define "odoo.nodeSelector" }}
{{- if .Values.K8S.Node }}
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: service
              operator: In
              values:
                - "{{ .Values.K8S.Node }}"
  podAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        podAffinityTerm:
          labelSelector:
            matchExpressions:
              - key: node
                operator: In
                values:
                  - "{{ .Values.K8S.Node }}"
          topologyKey: kubernetes.io/hostname
tolerations:
  - key: service
    operator: Equal
    value: "{{ .Values.K8S.Node }}"
    effect: NoSchedule
nodeSelector:
  service: "{{ .Values.K8S.Node }}"
{{- end }}
{{- end }}

{{/*
  Spread node-selector: igual que `odoo.nodeSelector` pero SIN podAffinity
  (que forza clumping en un único nodo). Usado por las réplicas extras
  (13-OdooReader, 14-NginxReader) para que puedan distribuirse en nodos
  distintos.

  Usa `K8S.ReplicaNode` como node group si está definido, si no cae a
  `K8S.Node` (mismo grupo que el primary). Esto permite tener un node group
  dedicado para los extras, separado del primary.

  Devuelve sólo `tolerations:` + `nodeSelector:` (no `affinity:` — el
  Deployment compone su propio bloque `affinity:` con node/pod rules).
*/}}
{{- define "odoo.nodeSelector.spread" }}
{{- $node := default .Values.K8S.Node .Values.K8S.ReplicaNode -}}
{{- if $node }}
tolerations:
  - key: service
    operator: Equal
    value: "{{ $node }}"
    effect: NoSchedule
nodeSelector:
  service: "{{ $node }}"
{{- end }}
{{- end }}

{{/*
  Devuelve el node group efectivo para los pods extras (réplicas).
  Usado por 13-OdooReader.yaml y 14-NginxReader.yaml para componer el bloque
  `nodeAffinity:` dentro de su `affinity:`. El template emite el VALOR
  literal (sin sufijos) — el caller lo usa donde necesite.
*/}}
{{- define "odoo.replicaNode" -}}
{{- default .Values.K8S.Node .Values.K8S.ReplicaNode -}}
{{- end }}

{{/*
  ¿Los Ingress de este tenant los sirve Traefik detrás de CloudFront?

  Devuelve una cadena no vacía sólo para `eks` + `Ingress.Odoo.Type=traefik`, que
  es el routing nuevo (CloudFront multi-tenant → NLB interno → Traefik en HTTP
  plano). La abrumadora mayoría de tenants sigue en `alb`, y el provider k8s también usa
  Traefik pero ahí SÍ termina TLS (entrypoint `websecure`), así que el provider
  entra en la condición a propósito.

  Lo usan 16-Ingress y 17-CustomIngress para no emitir dos cosas que en ese
  routing no significan nada:
    - las anotaciones `alb.ingress.kubernetes.io/*` (ver providers/_eks.tpl):
      hoy son inertes, pero documentan un balanceador que ya no existe.
    - el bloque `tls:` sin `secretName`: con el ALB es la pista para que el
      controller descubra el cert en ACM por hostname; con este Traefik no hay
      entrypoint TLS, y si algún día se añade uno serviría su cert autofirmado
      a todos los hosts declarados. El TLS lo termina CloudFront.
*/}}
{{- define "odoo.ingress.cloudfrontTraefik" -}}
{{- /* `default ""`: Ingress.Odoo.Type es null en values.yaml y `eq` con nil peta. */ -}}
{{- if and (eq .Values.K8S.Provider "eks") (eq (default "" .Values.Ingress.Odoo.Type) "traefik") -}}true{{- end -}}
{{- end }}

{{/*
  Lo mismo, pero para el Ingress de jupyter (self mode), que va por su PROPIA clase
  `Ingress.Jupyter.Type` y por otro ALB (`Ingress.Jupyter.Name`, con `inbound-cidrs`).

  Existe separado a proposito: las anotaciones que cuelgan del Service `jupyter` las
  lee el ALB que sirve el Ingress de jupyter, no el de odoo, asi que mover odoo a
  Traefik no las vuelve inertes. Hoy ninguna instancia pone jupyter en Traefik y este
  helper no cambia nada; esta para que el dia que se haga, las anotaciones se vayan
  con el ALB en vez de quedarse describiendo un routing que ya no existe.
*/}}
{{- define "odoo.ingress.cloudfrontTraefik.jupyter" -}}
{{- if and (eq .Values.K8S.Provider "eks") (eq (default "" .Values.Ingress.Jupyter.Type) "traefik") -}}true{{- end -}}
{{- end }}

{{- define "odoo.secretsRef" }}
{{- if eq .Values.Instance.Controller "oem" }}
- secretRef:
    name: odoo-secrets
{{- else }}
- configMapRef:
    name: odoo-secrets
{{- end }}
{{- end }}

{{/*
  Helper: volumeMount block para /home/odoo. UNIFICADO en los 3 storages
  (ebs/efs/fsx): SIEMPRE `subPath: odoo`. La PVC odoo-base tiene dos subdirs
  siblings:
    /odoo     — home del usuario (todo lo que ve el runtime aquí).
    /.manager — tokens/sessions de login-server, sólo visible para los
                containers que monten odoo.volumeMount.odooManager
                (aislamiento ESTRUCTURAL: el subPath no se monta en jupyter).
  Diferencias por storage (NO afectan a este mount — "solo cambia csi-loop"):
    - efs: /home/odoo/src y /home/odoo/.venv vienen de PVCs csi-loop
           (odoo-src/odoo-venv) — ver odoo.volumeMount.odooSrc. Isolation
           multi-tenant vía EFS Access Point dinámico.
    - ebs: PVC RWO dedicada por instancia; src/.venv son subdirs del subPath.
    - fsx: NO usado actualmente. OJO: con subPath=odoo uniforme NO hay
           aislamiento per-namespace sobre la FSx compartida; si se reactiva,
           rootear por namespace a nivel PV/AP, no aquí.

  Uso en cada container template:
    volumeMounts:
      {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
*/}}
{{- define "odoo.volumeMount.odooBase" -}}
- name: odoo-base
  mountPath: /home/odoo
  subPath: odoo
{{- end -}}

{{/*
  odoo.volumeMount.odooSrc — mounts DIRECTOS (sin subPath) de las dos PVCs
  csi-loop odoo-src y odoo-venv. Sólo se emite cuando Storage.Type=efs.

  Sirve /home/odoo/src (PVC odoo-src) y /home/odoo/.venv (PVC odoo-venv) vía
  csi-loop — UNA imagen ext4 loop por PVC sobre EFS, perf nativa para reads
  de código. Cada path es su propio volume montado DIRECTAMENTE (sin subPath).

  Por qué dos PVCs en vez de un único image con subPath src/.venv:
  replicaMode=overmount refresca la réplica haciendo over-mount sobre el
  target del driver (anchor MS_SHARED). La propagación de mount SÍ atraviesa
  un mount directo, pero NO atraviesa un bind subPath (kubelet lo crea
  MS_PRIVATE) → con subPath la réplica quedaba anclada a la imagen vieja.
  Separando src y .venv en dos PVCs montadas directas, el over-mount propaga.

  mountPropagation: HostToContainer (rslave) es OBLIGATORIO en overmount: el
  container debe ser slave del peer group del anchor para ver el contenido
  nuevo sin remount del kubelet. Inofensivo en fuse (FUSE refresca in-place,
  no genera over-mounts). HostToContainer NO requiere privileged (sólo
  Bidirectional lo requiere) → válido en runtime containers no-privilegiados.

  El role writer/replica del POD se decide a nivel volume (en
  odoo.volume.odooSrc.writer/replica) por persistentVolumeClaim.readOnly —
  el driver csi-loop usa ESE flag, no el del volumeMount, para el rol.

  Dos variantes a nivel container — defense in depth contra writes
  accidentales en runtime containers que sólo leen código:

    - odoo.volumeMount.odooSrc    → RW (sin readOnly en volumeMount). Usar
      en containers/jobs que SÍ escriben código: jupyter, container-updater,
      todos los Jobs admin (system-prepare, migrate, restore, rebuild, ...).
      En replica pods el PVC ya viene RO desde csi-loop — RW aquí no
      promociona a RW (kubelet respeta el RO del PVC).

    - odoo.volumeMount.odooSrc.ro → readOnly: true en volumeMount. Usar en
      runtime containers HTTP/cron que sólo leen: odoo, cron, cleaner.
      En writer pod (PVC RW) este flag fuerza RO local. En replica
      (PVC RO) es redundante pero harmless.

  /.manager NO va por csi-loop — vive en EFS AP directo vía subPath de
  odoo-data-efs, mountado sólo en los containers que lo necesitan
  (security + container-updater). Ese subPath es sobre el EFS AP (NFS
  directo, sin over-mount) → no le afecta esta restricción. Ver
  odoo.volumeMount.odooManager.

  Containers que no necesitan src/.venv (alloy, nginx, pgbouncer,
  metrics, security) lo omiten directamente.
*/}}
{{/*
  odoo.volumeMount.odooSrcOCI — los repos de la imagen, ENCIMA y por subPath.

  Estos tres mounts van SOBRE `/home/odoo/src`, que sigue siendo el volumen del
  tenant (el .img de csi-loop con EFS, `odoo-base` con EBS/FSx). Es decir: el
  almacenamiento del tenant NO se sustituye, se le tapan tres subdirectorios.

  De ahi salen las tres propiedades que se buscaban, y son las mismas en los tres
  tipos de almacenamiento — medido el 2026-08-29:

    - La RAIZ de `src` sigue siendo del tenant, asi que lo que se escriba ahi
      PERSISTE. Montando el overlay sobre la raiz, esta pasaba a ser la capa
      escribible: en EBS esa capa es local del nodo, o sea que un fichero creado
      ahi se perdia al reprogramar el pod, y en SILENCIO.
    - `platform` y `user` NO SE TOCAN: siguen exactamente donde estan hoy en cada
      modo (dentro del .img con EFS, dentro de `odoo-base` con EBS). Cero
      migracion de datos.
    - Lo unico efimero es el copy-up sobre los tres repos de la imagen, que es
      exactamente lo que debe serlo.

  ⚠️ Sin `mountPropagation` en estos tres: un over-mount NO propaga a traves de
  subPath (por eso el `replicaMode` por defecto es fuse). No estorba —las fuentes
  OCI no se refrescan, se cambia de semana con un rollout— pero el mount de la
  RAIZ si lleva propagacion y hay que conservarsela: de ella depende el refresco
  del ext4 del tenant en las replicas.
*/}}
{{- define "odoo.volumeMount.odooSrcOCI" -}}
{{- $ro := .ro | default false }}
{{- $repos := list "odoo" "enterprise" "themes" }}
{{- if .Values.Odoo.PlatformRef }}
{{- $repos = append $repos "platform" }}
{{- end }}
{{- range $repo := $repos }}
- name: odoo-sources
  mountPath: /home/odoo/src/{{ $repo }}
  subPath: {{ $repo }}
  {{- if $ro }}
  readOnly: true
  {{- end }}
{{- end }}
{{- end -}}

{{/*
  odoo.volumeMount.odooSrcBase — the sources volume a SECOND time, at
  /home/odoo/.src-base, WITHOUT the OCI image on top. Only with `SourcesRef`, and
  only in container-updater.

  Over /home/odoo/src the image hides the old git clones of odoo/enterprise/themes
  (~2,3 GB a tenant), so nobody could delete them. Through this path
  `system-prepare --sync-on-start` sees and empties them, and only those the image
  is serving at that moment; csi-loop's daily trim hands the space back to EFS.
*/}}
{{- define "odoo.volumeMount.odooSrcBase" -}}
{{- if .Values.Odoo.SourcesRef }}
{{- if eq .Values.Storage.Type "efs" }}
- name: odoo-src
  mountPath: /home/odoo/.src-base
{{- else }}
- name: odoo-base
  mountPath: /home/odoo/.src-base
  subPath: odoo/src
{{- end }}
{{- end }}
{{- end -}}

{{- define "odoo.volumeMount.odooSrc" -}}
{{- if eq .Values.Storage.Type "efs" }}
- name: odoo-src
  mountPath: /home/odoo/src
  mountPropagation: HostToContainer
- name: odoo-venv
  mountPath: /home/odoo/.venv
  mountPropagation: HostToContainer
{{- end }}
{{- if .Values.Odoo.SourcesRef }}
{{- include "odoo.volumeMount.odooSrcOCI" (dict "Values" .Values "ro" false) }}
{{- end }}
{{- end -}}

{{- define "odoo.volumeMount.odooSrc.ro" -}}
{{- if eq .Values.Storage.Type "efs" }}
- name: odoo-src
  mountPath: /home/odoo/src
  readOnly: true
  mountPropagation: HostToContainer
- name: odoo-venv
  mountPath: /home/odoo/.venv
  readOnly: true
  mountPropagation: HostToContainer
{{- end }}
{{- if .Values.Odoo.SourcesRef }}
{{- include "odoo.volumeMount.odooSrcOCI" (dict "Values" .Values "ro" true) }}
{{- end }}
{{- end -}}

{{/*
  odoo.volumeMount.odooManager — subPath mount de odoo-base en
  /home/odoo/.manager (subPath sibling de `odoo`, NO csi-loop).

  Se emite para Controller=oem en ebs y efs (no fsx — ahí .manager
  necesitaría colgar del subPath de namespace, no de la raíz). Sólo los
  containers que escriben/leen tokens lo invocan (security,
  container-updater); el resto ni siquiera tiene /home/odoo/.manager
  visible. El aislamiento es ESTRUCTURAL (subPath no montado en jupyter),
  mejor que perms e IDÉNTICO en ebs y efs.

  En efs el AP enforza uid=999/gid=999 sobre .manager; en ebs se preserva
  la propiedad real (login-server puede chown root + chmod 600 los tokens).
*/}}
{{- define "odoo.volumeMount.odooManager" -}}
{{- if eq .Values.Instance.Controller "oem" }}
- name: odoo-base
  mountPath: /home/odoo/.manager
  subPath: .manager
{{- end }}
{{- end -}}

{{/*
  odoo.volumeMount.odooAi — subPath mount de odoo-base en /home/odoo/.ai
  (sibling de `odoo`/`.manager`, NO csi-loop). Aloja credenciales + estado de
  los asistentes IA (Claude RC: CLAUDE_CONFIG_DIR; OpenCode: data/config). Se
  monta SÓLO en el contenedor `ai` — jupyter NO lo monta → el cliente desde el
  terminal NO puede leer los tokens de Claude/OpenCode de los devs. Aislamiento
  ESTRUCTURAL por subPath, idéntico en ebs/efs. oem + staging.
*/}}
{{- define "odoo.volumeMount.odooAi" -}}
{{- if and (eq .Values.Instance.Controller "oem") (eq .Values.Odoo.Stage "staging") }}
- name: odoo-base
  mountPath: /home/odoo/.ai
  subPath: .ai
{{- end }}
{{- end -}}

{{/*
  odoo.volumeMount.aiSshKey — monta SÓLO la deploy key del repo del usuario
  (id_rsa) en el contenedor `ai`, en /home/odoo/.ssh-key (misma ruta que usa
  container-updater / git_wrapper), para que Claude/OpenCode puedan `git push`
  sin exponer el resto del secret ssh-keys (p.ej. odoo_enterprise). RO.
*/}}
{{- define "odoo.volumeMount.aiSshKey" -}}
{{- if and (eq .Values.Instance.Controller "oem") (eq .Values.Odoo.Stage "staging") }}
- name: ai-ssh-key
  mountPath: /home/odoo/.ssh-key
  readOnly: true
{{- end }}
{{- end -}}

{{/*
  odoo.volume.odooSrc.writer / replica — entries de los volumes odoo-src
  (=/home/odoo/src) y odoo-venv (=/home/odoo/.venv), dos PVCs csi-loop.
  readOnly se setea a nivel `persistentVolumeClaim` porque el driver
  csi-loop usa ese flag (NO el de volumeMount) para decidir el rol
  writer/replica de la imagen.

  Llamar después de `odoo.volumes` desde 10-Odoo, 11-Cron, 13-OdooReader
  y los Jobs admin. Sólo el deployment de readers usa la variante replica.
*/}}
{{/*
  odoo.volume.odooSources — el volumen con las fuentes de la imagen OCI.

  Es SEPARADO de `odoo-src` a proposito. `odoo-src` sigue siendo el
  almacenamiento del tenant tal cual (la PVC csi-loop con EFS, `odoo-base` con
  EBS/FSx), y este solo aporta `odoo`, `enterprise` y `themes`, que se montan
  ENCIMA por subPath (ver odoo.volumeMount.odooSrcOCI).

  Lo que se gana separandolos: el layout es el MISMO en los tres tipos de
  almacenamiento, `platform` y `user` se quedan donde ya estan —cero migracion de
  datos— y la raiz de /home/odoo/src conserva su persistencia y su propagacion.

  🔑 Es un volumen CSI EN LINEA, no una PVC, porque `sourcesRef` tiene que estar
  en el spec del pod: es lo que dispara el rollout al cambiar de semana. En una
  PVC los volumeAttributes se fijan al crearla y cambiar la semana no reiniciaria
  nada.

  🔑 SIN `fileSystemId`: la capa escribible del overlay va a disco local del nodo
  (ver ociStandaloneRequested en el driver). No hace falta que persista — solo
  recoge copy-ups y whiteouts sobre las fuentes, y el codigo de verdad se cambia
  con la semana, que es un rollout. Y asi el volumen no depende de EFS, que es lo
  que permite usarlo con `odoo-base` en EBS o FSx.

  🔑 `seLinuxLevel` lo decide el chart (`odoo.mcsLevel`, determinista por
  namespace) y se lo pasa al driver, que NO puede deducirlo: no tiene cliente de
  Kubernetes. Sin el, en un nodo con SELinux el tenant no podria escribir sobre
  nada que venga de la imagen — el overlay quedaria de solo lectura efectiva.

  ⚠️ Para la migracion: hay que VACIAR `odoo`, `enterprise` y `themes` del
  almacenamiento del tenant. Si se quedan, siguen ocupando sitio (y en EFS, en el
  .img) aunque queden tapados por estos mounts.
*/}}
{{- define "odoo.volume.odooSources" -}}
{{- if .Values.Odoo.SourcesRef }}
- name: odoo-sources
  csi:
    driver: loop-image.csi.processcontrol.io
    volumeAttributes:
      sourcesRef: {{ .Values.Odoo.SourcesRef | quote }}
      {{- with .Values.Odoo.PlatformRef }}
      platformRef: {{ . | quote }}
      {{- end }}
      seLinuxLevel: {{ include "odoo.mcsLevel" . | quote }}
      {{- /*
        fsGroup va aqui ADEMAS de en el podSecurityContext, y no es una
        duplicacion gratuita: el CSIDriver de csi-loop declara
        `fsGroupPolicy: None`, asi que kubelet NO aplica el fsGroup del pod a
        este volumen -- lo tiene que hacer el driver, y solo lo ve por aqui.
        Sin el, la raiz de la capa escribible queda con grupo `root` y sin
        setgid, en vez del `drwxrwsr-x root odoo` que tienen platform/ y user/.
        Hoy no se nota porque los contenedores corren como root; el dia que uno
        no lo haga, dejaria de poder escribir. Los dos numeros salen del mismo
        helper para que no puedan divergir.
      */}}
      fsGroup: {{ include "odoo.fsGroup" . | quote }}
      {{- /* Se pasa el NOMBRE de la PVC, no una ruta: en EFS la StorageClass usa
             `subPathPattern: ${.PV.name}` + `ensureUniqueDirectory`, asi que el
             directorio lleva un uuid del provisioner y no hay ruta derivable.
             Sin este atributo el driver cae al disco del nodo. */}}
      upperClaimName: {{ include "odoo.odooBaseClaimName" . | quote }}
      upperSubPath: "odoo/.overlay"
      upperSize: "2Gi"
      sourcesWritable: "true"
{{- end }}
{{- end -}}

{{/*
  Dos volumenes independientes, y por eso el resultado es igual en los tres tipos
  de almacenamiento:

    - `odoo-src` (+ `odoo-venv`): el almacenamiento del tenant, EXACTAMENTE como
      siempre. Solo con EFS, porque son PVCs de csi-loop; con EBS/FSx esas rutas
      ya vienen dentro de `odoo-base`.
    - `odoo-sources`: las fuentes de la imagen OCI, si hay `SourcesRef`. Se monta
      ENCIMA por subPath (`odoo.volumeMount.odooSrcOCI`), sin sustituir la raiz.

  `readOnly` va a nivel de `persistentVolumeClaim` porque el driver csi-loop usa
  ESE flag —no el del volumeMount— para decidir el rol writer/replica del .img.

  ⚠️ Y `odoo-sources` va SIN `readOnly` TAMBIEN EN LA REPLICA. Parece un descuido
  y no lo es: ponerselo introduce un fallo mudo.

  Ese volumen no lleva `fileSystemId`, asi que el driver lo sirve por el camino
  standalone: la capa escribible es LOCAL del nodo, no hay recurso compartido
  entre nodos y por tanto no hay rol que repartir — cada nodo monta la suya.

  Lo que si comparten writer y replica es el overlay cuando caen en el MISMO
  nodo, y ahi el modo lo fija EL PRIMERO que publica: `reuseStandaloneOverlay`
  no vuelve a mirar el `readOnly`, y ese camino —al contrario que el del .img—
  NO sabe promover de RO a RW. Con la replica marcada RO y publicando primero,
  el overlay se montaria sin upperdir y el writer lo heredaria sin poder
  escribir sobre las fuentes, sin un solo error por medio.

  Lo efimero que la replica pueda escribir ahi es su propio copy-up local, que
  es exactamente lo que debe perderse al reprogramar el pod.
*/}}
{{- define "odoo.volume.odooSrc.writer" -}}
{{- if eq .Values.Storage.Type "efs" }}
- name: odoo-src
  persistentVolumeClaim:
    claimName: odoo-src
- name: odoo-venv
  persistentVolumeClaim:
    claimName: odoo-venv
{{- end }}
{{- include "odoo.volume.odooSources" . }}
{{- end -}}

{{- define "odoo.volume.odooSrc.replica" -}}
{{- if eq .Values.Storage.Type "efs" }}
- name: odoo-src
  persistentVolumeClaim:
    claimName: odoo-src
    readOnly: true
- name: odoo-venv
  persistentVolumeClaim:
    claimName: odoo-venv
    readOnly: true
{{- end }}
{{- include "odoo.volume.odooSources" . }}
{{- end -}}

{{- define "odoo.volumes" }}
- name: odoo-base
  persistentVolumeClaim:
    claimName: {{ include "odoo.odooBaseClaimName" . }}
{{- if and (ne .Values.Instance.Controller "oem") (eq .Values.Storage.Type "ebs") }}
# Type=efs/fsx: /home/odoo/data lives inside the shared odoo-base volume,
# no separate PVC. Solo ebs separa odoo-data.
- name: odoo-data
  persistentVolumeClaim:
    claimName: odoo-data
{{- end }}
- name: backup-data
  persistentVolumeClaim:
    claimName: backup-data
- name: config-files
  configMap:
    name: odoo-config-files
- name: ssh-keys
  secret:
    secretName: {{ include "odoo.sshKeysSecret" . }}
    defaultMode: 256
{{- if and (eq .Values.Instance.Controller "oem") (eq .Values.Odoo.Stage "staging") }}
# Solo id_rsa (deploy key del repo del usuario) para el contenedor `ai`:
# Claude/OpenCode pueden git push sin ver el resto de ssh-keys (odoo_enterprise).
- name: ai-ssh-key
  secret:
    secretName: {{ include "odoo.sshKeysSecret" . }}
    items:
      - key: id_rsa
        path: id_rsa
    defaultMode: 256
{{- end }}
- name: pg-version
  configMap:
    name: odoo-config
    items:
      - key: PGVERSION
        path: default_version
{{- if or .Values.Postgres.MasterSecret.Name .Values.Source.MasterSecret.Name }}
{{- /* container-updater reads the master credentials from these files when it
       uses them: its environment is frozen at start and a rotation never reaches it. */}}
{{- if include "odoo.sealed" . }}
{{- /* Each key only from its source. ESO overwrites the Secret's last-applied
       annotation, so keys the chart stopped rendering when sealing stay in
       odoo-admin-secrets with their old value; read first, they would win. */}}
- name: odoo-admin-secrets
  projected:
    defaultMode: 292
    sources:
      - secret:
          name: odoo-admin-secrets
          optional: true
          items:
            {{- if .Values.Postgres.MasterSecret.Name }}
            - key: PGMASTERUSER
              path: PGMASTERUSER
            - key: PGMASTERPASSWORD
              path: PGMASTERPASSWORD
            {{- end }}
            {{- if .Values.Source.MasterSecret.Name }}
            - key: PGSOURCEUSER
              path: PGSOURCEUSER
            - key: PGSOURCEPASSWORD
              path: PGSOURCEPASSWORD
            {{- end }}
      - secret:
          name: odoo-admin-sealed
          optional: true
{{- else }}
- name: odoo-admin-secrets
  secret:
    secretName: odoo-admin-secrets
    defaultMode: 292
{{- end }}
{{- end }}
{{- end }}

{{/*
  EFS-specific helper: monta /home/odoo/src vía sidecar (mount propagation).
  Devuelve volumeMounts adicionales para containers de runtime (odoo, jupyter, etc).
  El sidecar mount-manager monta el ext4 loop image (RW en writer, RO en
  replicas) sobre /home/odoo/src; runtime containers lo ven vía
  HostToContainer propagation.

  Usage en template de container:
    {{- include "odoo.volumeMounts.efs" . | nindent 4 }}
*/}}
{{- define "odoo.volumeMounts.efs" -}}
{{- if eq .Values.Storage.Type "efs" }}
- name: odoo-base
  mountPath: /home/odoo
  mountPropagation: HostToContainer
{{- else }}
- name: odoo-base
  mountPath: /home/odoo/
{{- end }}
{{- end -}}

{{/*
  EFS writer Jobs (system-prepare, odoo-migrate, rebuild, restore, etc.) que
  modifican /home/odoo/src necesitan privileged cuando Storage.Type=efs para
  poder hacer truncate + mkfs.ext4 + losetup + mount loopback del archivo
  /home/odoo/.config/src.img.next dentro del propio Job (sin emptyDir).

  Usage:
      containers:
        - name: ...
          {{- include "odoo.efs.writerSecurityContext" . | nindent 10 }}
          volumeMounts:
            - name: odoo-base
              mountPath: /home/odoo/
            ...
*/}}
{{- define "odoo.efs.writerSecurityContext" -}}
{{- if eq .Values.Storage.Type "efs" }}
securityContext:
  privileged: true
{{- end }}
{{- end -}}

{{/*
  Provider-specific helpers live in providers/_eks.tpl, etc.
  Call them directly with: {{ include (printf "odoo.provider.%s.helperName" .Values.K8S.Provider) . }}
*/}}
