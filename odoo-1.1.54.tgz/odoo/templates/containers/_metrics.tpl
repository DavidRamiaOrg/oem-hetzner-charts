{{- define "odoo.container.metrics" }}
- name: metrics
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
  command:
    - metrics-server
  ports:
    - name: memory-metrics
      containerPort: 9191
  # PG* del tenant: solo el pod writer mide el tamaño de la BD (odoo_database_size_bytes).
  envFrom:
    - configMapRef:
        name: odoo-config
    {{- include "odoo.secretsRef" . | nindent 4 }}
  env:
    # REPLICA_ID — downward API (label replica-id del pod). Se usa como label
    # en las métricas Prometheus emitidas por metrics-server.
    - name: REPLICA_ID
      valueFrom:
        fieldRef:
          fieldPath: metadata.labels['replica-id']
    # POD_ROLE — downward API (label `role`): "writer" (single: pod odoo,
    # multi: pod cron) o "replica". metrics-server sólo emite las métricas de
    # ESTADO de instancia (odoo_service_status, odoo_update_sources_failed) cuando
    # role=writer → 1 sola serie por instancia (nunca desde las réplicas).
    - name: POD_ROLE
      valueFrom:
        fieldRef:
          fieldPath: metadata.labels['role']
  volumeMounts:
    {{- include "odoo.volumeMount.k8sNamespace" . | nindent 4 }}
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      cpu: 1m
      memory: 16Mi
    limits:
      cpu: 100m
      memory: 128Mi
{{- end }}
