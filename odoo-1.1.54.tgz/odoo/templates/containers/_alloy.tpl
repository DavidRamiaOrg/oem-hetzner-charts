{{- define "odoo.container.alloy" }}
- name: alloy
  image: "{{ .Values.Images.Alloy.Image }}:{{ .Values.Images.Alloy.Version }}{{- with .Values.Images.Alloy.Branch }}-{{ . }}{{- end }}"
  env:
    - name: NAMESPACE
      value: "{{ .Release.Namespace }}"
    {{- if eq .Values.Odoo.Stage "production" }}
    # Self-probe: only emit probe_* metrics for production instances.
    # /web/health was added in Odoo 15 — older versions get probed at
    # /web/webclient/version_info via JSON-RPC POST.
    - name: PROBE_URL
      {{- if ge (.Values.Odoo.Version | float64 | int) 15 }}
      value: "https://{{ .Values.Odoo.Subdomain | default .Release.Namespace }}.{{ .Values.Cluster.Domain }}/web/health?db_server_status=True"
      {{- else }}
      value: "https://{{ .Values.Odoo.Subdomain | default .Release.Namespace }}.{{ .Values.Cluster.Domain }}/web/webclient/version_info"
      {{- end }}
    - name: PROBE_MODULE
      {{- if ge (.Values.Odoo.Version | float64 | int) 15 }}
      value: "http_health"
      {{- else }}
      value: "http_jsonrpc"
      {{- end }}
    {{- end }}
  volumeMounts:
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      cpu: 1m
      memory: 32Mi
    limits:
      cpu: 250m
      memory: 256Mi
  ports:
    - name: metrics
      containerPort: 9100
{{- end }}
