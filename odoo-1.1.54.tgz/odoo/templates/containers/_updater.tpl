{{/* container-updater: self runs update-odoo (weekly schedule), oem runs sleep (exec on demand) */}}
{{- define "odoo.container.updater" }}
- name: container-updater
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
{{- if eq .Values.Instance.Controller "self" }}
  command:
    - update-odoo
{{- else }}
  {{- /* On every start, catch up with what changed while the instance was asleep:
         Odoo/Enterprise/Themes revisions and the database's PostgreSQL settings. It
         restarts Odoo only if something changed. `|| true`: an image without the
         option still just sleeps. */}}
  command:
    - bash
    - -c
    - "system-prepare --sync-on-start || true; exec sleep infinity"
{{- end }}
  envFrom:
    - secretRef:
        name: odoo-admin-secrets
    {{- if include "odoo.sealed" $ }}
    - secretRef:
        name: odoo-admin-sealed
        optional: true
    {{- end }}
    - configMapRef:
        name: odoo-config
    {{- include "odoo.secretsRef" . | nindent 4 }}
{{- if and (eq .Values.Instance.Controller "oem") .Values.ArgoGateway.Url }}
  env:
    - name: ARGOCD_GATEWAY_URL
      value: "{{ .Values.ArgoGateway.Url }}"
    {{- if .Values.ArgoGateway.Secret }}
    - name: ARGOCD_GATEWAY_SECRET
      value: "{{ .Values.ArgoGateway.Secret }}"
    {{- end }}
    {{- if .Values.ArgoGateway.TokenSecret }}
    - name: ARGOCD_APP_TOKEN
      valueFrom:
        secretKeyRef:
          name: argo-gateway-token
          key: token
    {{- else if .Values.ArgoGateway.Token }}
    - name: ARGOCD_APP_TOKEN
      value: "{{ .Values.ArgoGateway.Token }}"
    {{- end }}
    {{- if eq .Values.Instance.Controller "oem" }}
    # La identidad de UNA ejecucion. Un contenedor reiniciado es una ejecucion
    # nueva, que es lo que hace a OEM reiniciar su cursor.
    - name: OEM_POD_NAME
      valueFrom:
        fieldRef:
          fieldPath: metadata.name
    {{- end }}
{{- end }}
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      cpu: 10m
      memory: 128Mi
    limits:
      cpu: 2000m
      memory: 3Gi
  volumeMounts:
    {{- /* El token de eventos va SOLO aqui dentro del pod: `container-updater`
           es el unico contenedor que publica (aqui corre make-backup). El
           contenedor `odoo`, que ejecuta codigo del cliente, se queda sin
           ninguna credencial de apiserver. */ -}}
    {{- include "odoo.volumeMount.eventsToken" . | nindent 4 }}
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
    {{- /* container-updater hace git pull / refresh de repos en src/.
           Junto con jupyter es el único container que escribe código.
           Monta .manager porque maneja tokens de la imagen / actualizaciones
           coordinadas con login-server (security). */ -}}
    {{- include "odoo.volumeMount.odooSrc" . | nindent 4 }}
    {{- if .Values.Odoo.SourcesRef }}
    {{- include "odoo.volumeMount.odooSrcBase" . | nindent 4 }}
    {{- end }}
    {{- include "odoo.volumeMount.odooManager" . | nindent 4 }}
{{- if and (ne .Values.Instance.Controller "oem") (eq .Values.Storage.Type "block") }}
    - name: odoo-data
      mountPath: /home/odoo/data
{{- end }}
    - name: backup-data
      mountPath: /home/odoo/backups
      subPath: "{{ .Values.Customer.Name }}/backups"
    - name: backup-data
      mountPath: /tmp
      subPath: "{{ .Values.Customer.Name }}/tmp"
    - name: pg-version
      mountPath: /etc/postgresql-common/default_version
      subPath: default_version
    - name: ssh-keys
      mountPath: /home/odoo/.ssh-key/
      readOnly: true
{{- if or .Values.Postgres.MasterSecret.Name .Values.Source.MasterSecret.Name }}
    - name: odoo-admin-secrets
      mountPath: /run/secrets/odoo-admin
      readOnly: true
{{- end }}
{{- end }}
