{{- define "odoo.container.cron" }}
- name: cron
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
  command:
    - system-init
  args:
    - "--mode=cron"
    - "--cron-threads={{ .Values.Odoo.Cron }}"
    - "--limit-memory-hard={{ .Values.Odoo.MemoryLimitHard }}"
    - "--limit-memory-soft={{ .Values.Odoo.MemoryLimitSoft }}"
    - "--limit-time-cpu={{ .Values.Odoo.CPULimit }}"
    - "--limit-time-real={{ .Values.Odoo.RealLimit }}"
  readinessProbe:
    exec:
      command:
        - cat
        - /var/run/odoo.status
    initialDelaySeconds: 5
    periodSeconds: 5
  envFrom:
    - configMapRef:
        name: odoo-config
    {{- include "odoo.secretsRef" . | nindent 4 }}
  volumeMounts:
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
    {{- /* cron sólo LEE src/.venv para correr scheduled actions — no
           escribe. Mount RO defensivo. NO monta .manager. */ -}}
    {{- include "odoo.volumeMount.odooSrc.ro" . | nindent 4 }}
{{- if and (ne .Values.Instance.Controller "oem") (eq .Values.Storage.Type "block") }}
    - name: odoo-data
      mountPath: /home/odoo/data
{{- end }}
    - name: backup-data
      mountPath: /home/odoo/backups
      subPath: "{{ .Values.Customer.Name }}/backups"
    - name: pg-version
      mountPath: /etc/postgresql-common/default_version
      subPath: default_version
    - name: config-files
      mountPath: /home/odoo/.manager/config_files
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      {{- if .Values.Resources.Cron.RequestCPU }}
      cpu: "{{ .Values.Resources.Cron.RequestCPU }}"
      {{- end }}
      memory: "{{ .Values.Resources.Cron.RequestRAM }}"
    limits:
      {{- if .Values.Resources.Cron.LimitCPU }}
      cpu: "{{ .Values.Resources.Cron.LimitCPU }}"
      {{- end }}
      memory: "{{ .Values.Resources.Cron.LimitRAM }}"
{{- end }}
