{{- /* ============================================================================
       UNICO numero de configuracion del handoff de nginx con el balanceador.

       Es lo que tarda el ALB en converger, y es la MISMA magnitud en las dos
       direcciones: dar healthy un target nuevo y dejar de enrutar a uno que se va.
       20s = health check a intervalo 5s con umbral 2 (10s minimos) + propagacion del
       registro. Medido en el target group real (2026-08-04).

       De aqui salen las TRES cosas, no hay otro numero que tocar:

         minReadySeconds  = N     (12-Nginx, 14-NginxReader)  mitad de ENTRADA
         preStop sleep    = N     (este fichero)              mitad de SALIDA
         terminationGrace = N + 5 (12-Nginx, 14-NginxReader)  preStop + salida de nginx
                                  (con Instance.LongOp el margen es otro: ver
                                   odoo.nginx.terminationGraceSeconds)

       La gracia SIEMPRE tiene que ser mayor que el preStop: si el kubelet cortase el
       preStop con SIGKILL volveria el 502 que todo esto evita. Derivarla en vez de
       fijarla a mano es justamente para que no se pueda descuadrar.

       OJO con como muere este contenedor, porque el margen depende de eso: la imagen
       declara STOPSIGNAL SIGQUIT (verificado en la config de k8s-odoo/nginx), asi que
       el kubelet NO manda SIGTERM sino SIGQUIT, que en nginx es apagado GRACIOSO — el
       worker no sale hasta drenar lo que tenga en vuelo y `worker_shutdown_timeout` no
       esta puesto, o sea que el unico limite real es esta gracia. Para trafico normal
       los 5s sobran igualmente: cuando termina el preStop el pod lleva 20s fuera de los
       endpoints y solo pueden quedar peticiones ya empezadas. Lo que si cambia el
       calculo es el long-op — ver odoo.nginx.terminationGraceSeconds mas abajo.

       El PROBLEMA que resuelve: el ALB tiene su propia vision de que targets estan vivos
       y va unos segundos por detras del cluster en ambos sentidos. Sin esto, el rollout
       retira el pod viejo antes de que el ALB enrute al nuevo. Medido el 01-ago-2026
       migrando celeritas01: 4 peticiones perdidas de 1.340 (99,70%), una por tenant,
       exactamente en el instante en que desaparecia el pod viejo.

       POR QUE UN TIEMPO FIJO Y NO EL READINESS GATE DEL ALB: el gate
       (elbv2.k8s.aws/pod-readiness-gate-inject en el namespace) es mas preciso — espera la
       señal real de healthy — pero es FAIL-CLOSED: si el aws-load-balancer-controller no
       reconcilia, el pod se queda Running y nunca Ready, o sea invisible (fuera de los
       endpoints del Service). En un rollout eso solo lo atasca (el viejo sigue sirviendo),
       pero en un ARRANQUE EN FRIO —desalojo, consolidacion de Karpenter, despertar de una
       instancia suspendida, instancia nueva— deja el nginx caido. Y no se sale sin quitar
       la etiqueta del namespace y desactivar el selfHeal de ArgoCD A MANO. Con 170+
       instancias y nadie mirando cada una, perder alguna peticion en un caso hipotetico es
       mejor que colgarse esperando a un humano: esto falla ABIERTO.

       No es un value a proposito: no se ajusta por instancia.
       ============================================================================ */}}
{{- define "odoo.nginx.lbLagSeconds" -}}20{{- end }}

{{- /* ============================================================================
       Deadline por SALTO de la cadena del long-op, en segundos.

       Espejo de INITIAL_TIMEOUT_MS en lua/longop.lua de la imagen nginx (>= 1.1.3),
       que es lo que nginx espera al upstream antes de emitir el 303 al cliente. NO es
       el techo de la operacion entera (esa la limita MAX_TOTAL_DURATION_SEC = 900s en
       la misma Lua): es lo que dura el tramo que hay en vuelo en un instante dado.
       Si cambia en la imagen, hay que cambiarlo aqui — el chart no puede leerlo.
       ============================================================================ */}}
{{- define "odoo.nginx.longOpHopSeconds" -}}100{{- end }}

{{- /* ============================================================================
       Instance.LongOp, normalizado. Devuelve "1" si esta activo y "" si no.

       NO uses `if .Values.Instance.LongOp` directamente: OEM manda TODOS los values
       como `helm.parameters`, o sea como CADENAS, y en Go templates la cadena
       "false" es truthy. El dia que kube_manager empiece a emitir el parametro para
       todas las instancias —lo natural, ya que emite el resto— cada tenant con
       `Instance.LongOp=false` activaria la cadena, y los que tengan Replicas>0
       reventarian el render contra el `fail` de abajo. Es decir: el modo seguro
       (apagado) seria el que rompe.

       Se acepta el booleano nativo (values.yaml, `--set` con true/false) y las
       cadenas "true"/"1"; cualquier otra cosa es apagado.
       ============================================================================ */}}
{{- define "odoo.nginx.longOpEnabled" -}}
{{- $v := .Values.Instance.LongOp -}}
{{- if kindIs "string" $v -}}
{{- if or (eq (lower $v) "true") (eq $v "1") -}}1{{- end -}}
{{- else if $v -}}1{{- end -}}
{{- end }}

{{- /* ============================================================================
       terminationGracePeriodSeconds del pod nginx (12-Nginx y 14-NginxReader).

       SIN long-op: lbLag + 5. Es lo de siempre y no cambia para nadie — la inmensa
       mayoria de tenants sigue detras del ALB y renderiza exactamente igual que antes.

       CON long-op: lbLag + un salto entero + 10 (=130s hoy). Lo que compra NO es
       salvarle la respuesta al cliente: eso no lo arregla ningun numero, porque el
       estado de la cadena vive en la RAM de ESTE pod y el reintento llega como una
       peticion HTTP nueva que el Service enruta al pod que este Ready — que durante un
       relevo ya no es este. Lo que compra es no cortar a Odoo A MITAD: cuando expira el
       preStop, nginx puede tener abierta contra :8069 una llamada de fondo de hasta
       900s (una instalacion de modulos, tipicamente), y con la gracia de 25s el kubelet
       la mataba con SIGKILL 5s despues del SIGQUIT, abortandola en un punto arbitrario.

       Por que sale casi gratis: con SIGQUIT el apagado es gracioso, o sea que el worker
       sale EN CUANTO drena; si no hay nada en vuelo —el caso normal— el pod desaparece
       igual de rapido que antes y la gracia no se llega a consumir. El precio del caso
       malo lo pagan solo los tenants con LongOp=true: un drain de Karpenter puede
       esperar hasta ~130s por ese pod.

       Un salto y no los 900s del techo a proposito: cubrir la operacion entera dejaria
       un nginx imposible de drenar durante 15 minutos, y el tramo que de verdad se
       corta a mitad es el del salto en curso.
       ============================================================================ */}}
{{- define "odoo.nginx.terminationGraceSeconds" -}}
{{- $lag := int (include "odoo.nginx.lbLagSeconds" .) -}}
{{- if include "odoo.nginx.longOpEnabled" . -}}
{{- add $lag (int (include "odoo.nginx.longOpHopSeconds" .)) 10 -}}
{{- else -}}
{{- add $lag 5 -}}
{{- end -}}
{{- end }}

{{- /* ============================================================================
       El long-op CONVIVE con varias replicas de nginx desde la imagen 1.1.3.

       El problema, y por que no bastaba con un guardarrail: el estado de la cadena
       (`lua_shared_dict longop_state`) es memoria del proceso. El 303 hace que el
       reintento vuelva como una peticion HTTP nueva, y el Service `nginx`
       (15-Services) selecciona por `name: nginx` SIN sessionAffinity, asi que la
       reparte entre todos los pods con esa etiqueta — el primario mas un
       `nginx-replica-N` (14-NginxReader) por cada Odoo.Replicas. Con N+1 pods el
       reintento acertaria 1 de cada N+1 veces y el resto degradaria al azar, que es
       la peor clase de fallo: no rompe, falla a veces y sin rastro en los logs.

       Como se resuelve (imagen 1.1.3, lua/longop.lua + location @longop_peer): la IP
       del pod —NGINX_POD_IP, downward API, mas abajo en este mismo fichero— viaja
       DENTRO del UUID, que ya iba firmado entero; el pod que recibe un reintento
       ajeno lo reenvia al dueño. No hace falta stickiness en el balanceador, que
       habria que resolver distinto en ALB y que CloudFront directamente no ofrece,
       ni externalizar el estado.

       Lo que SIGUE siendo cierto: si el pod dueño muere, su operacion se pierde (el
       reintento recibe 410). Es el mismo comportamiento que con un solo pod, no una
       regresion de las replicas.

       ⚠️ Version minima: con la imagen 1.1.2 el UUID no lleva identidad y el reenvio
       no existe, asi que ahi la combinacion SI degrada. values.yaml exige >= 1.1.3
       para LongOp por este motivo, ademas de por la inyeccion de X-Forwarded-Host.
       ============================================================================ */}}
{{- define "odoo.container.nginx" }}
- name: nginx
  image: "{{ .Values.Images.Nginx.Image }}:{{ .Values.Images.Nginx.Version }}{{- with .Values.Images.Nginx.Branch }}-{{ . }}{{- end }}"
  env:
    - name: PGDATABASE
      valueFrom:
        configMapKeyRef:
          key: PGDATABASE
          name: odoo-config
{{- /* Scale-to-zero (idle suspend / wake) — OEM stagings only. nginx flips the
       instance's ArgoCD Application Instance.Status between run/system_down via
       the ArgoGateway (same path as the dashboard's manual shutdown/start).
       Driven entirely by Instance.IdleSuspend (0 = disabled, no separate flag).
       PGDATABASE (above) == the Application name, used by the Lua as the wake
       target. */ -}}
{{- if and (eq .Values.Instance.Controller "oem") (eq .Values.Odoo.Stage "staging") .Values.ArgoGateway.Url (gt (int .Values.Instance.IdleSuspend) 0) }}
    - name: IDLEWAKE_IDLE_MINUTES
      value: "{{ .Values.Instance.IdleSuspend }}"
    - name: ARGOCD_GATEWAY_URL
      value: "{{ .Values.ArgoGateway.Url }}"
    {{- if .Values.ArgoGateway.Secret }}
    - name: ARGOCD_GATEWAY_SECRET
      value: "{{ .Values.ArgoGateway.Secret }}"
    {{- end }}
    {{- if .Values.ArgoGateway.TokenSecret }}
    - name: ARGOCD_APP_TOKEN
      valueFrom:
        secretKeyRef:
          name: argo-gateway-token
          key: token
    {{- else if .Values.ArgoGateway.Token }}
    - name: ARGOCD_APP_TOKEN
      value: "{{ .Values.ArgoGateway.Token }}"
    {{- end }}
{{- end }}
{{- /* Long-op: envuelve los POST largos en la cadena de 303 de nginx para que no
       los corte el timeout de origen de CloudFront (120s por defecto).
       Interruptor único `Instance.LongOp` (default false). La imagen exige
       LONGOP_SECRET solo cuando LONGOP_ENABLED está puesto, así que ambos van
       juntos.

       La clave con la que se firma el UUID de la cadena es SUYA, no el
       PGPASSWORD del tenant: reutilizar la credencial de Aurora juntaba dos
       secretos de propósito distinto en un valor, de modo que rotar la
       contraseña de la BD mataba las operaciones en vuelo (kubelet no propaga
       env desde secretKeyRef → hace falta reiniciar nginx) y quien pudiera leer
       el Secret se llevaba las dos cosas a la vez. Se genera en
       02-Secrets.yaml, ahí está el porqué de que viva en el MISMO objeto que
       PGPASSWORD.

       SIEMPRE por referencia y nunca interpolada: el valor se re-randomiza en
       cada `helm template` y solo el `ignoreDifferences` sobre /data y
       /stringData de odoo-secrets lo mantiene estable en el cluster.
       Interpolarlo aquí daría un env distinto en cada sync y reiniciaría nginx
       sin parar.

       Contrapartida (sin cambios): un cambio del valor se adopta en el
       siguiente arranque del pod. No rompe nada — la clave es interna a nginx y
       el estado de las operaciones en vuelo vive en la RAM de ese pod. */ -}}
{{- if include "odoo.nginx.longOpEnabled" . }}
    - name: LONGOP_ENABLED
      value: "1"
    {{- /* Identidad del pod para el enrutado del reintento entre replicas.
           El estado de la cadena vive en la RAM de UN pod y el Service `nginx`
           reparte entre todos ellos sin afinidad; el UUID lleva esta IP firmada
           dentro, y el pod que recibe un reintento ajeno lo reenvia al dueño
           (location @longop_peer, imagen >= 1.1.3). Es lo que permite que
           Odoo.Replicas>0 y LongOp convivan sin stickiness en el balanceador,
           que no existe en CloudFront. */}}
    - name: NGINX_POD_IP
      valueFrom:
        fieldRef:
          fieldPath: status.podIP
    - name: LONGOP_SECRET
    {{- if eq .Values.Instance.Controller "oem" }}
      valueFrom:
        secretKeyRef:
          name: odoo-secrets
          key: LONGOP_SECRET
    {{- else }}
      {{- /* self: odoo-secrets es un ConfigMap, no un Secret (odoo.secretsRef). */}}
      valueFrom:
        configMapKeyRef:
          name: odoo-secrets
          key: LONGOP_SECRET
    {{- end }}
{{- end }}
  ports:
    - name: nginx
      containerPort: 8080
  readinessProbe:
    httpGet:
      port: nginx
      path: /health_check
    initialDelaySeconds: 3
  lifecycle:
    preStop:
      exec:
        {{- /* Mitad de SALIDA: mantiene nginx sirviendo mientras el ALB lo saca de
               rotacion. Ver odoo.nginx.lbLagSeconds arriba. */}}
        command: ["/bin/sleep", "{{ include "odoo.nginx.lbLagSeconds" . }}"]
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  {{- /* MEMORIA: el request NO es "lo poco que gasta", es lo que el kubelet
         considera suyo al elegir a quien desalojar. Medido en reposo el
         contenedor entero ocupa ~18Mi, o sea que con los 8Mi de antes nginx
         estaba SIEMPRE por encima de su request y era el candidato preferente
         al desalojo del pod bajo presion de memoria del nodo — y desalojar
         nginx tumba el ingress del tenant entero, porque es el unico camino de
         entrada. 64Mi cubre la base mas el crecimiento del `lua_shared_dict`
         del long-op (64m declarados, unos KB residentes en reposo, pero pasan a
         residentes segun se llena) y sigue siendo calderilla para el scheduler.

         El limite se queda en 512Mi a proposito: da holgura para la base + el
         shdict + los buffers de cuerpo. El `client_body_buffer_size` de 16M que
         traia la imagen 1.1.2 (con el que bastaban ~32 peticiones concurrentes
         con cuerpo grande para reventar cualquier limite razonable) se corrigio
         en la 1.1.3 bajandolo a 256k — se arreglo en la imagen, no aqui. */}}
  resources:
    requests:
      cpu: 10m
      memory: 64Mi
    limits:
      cpu: 500m
      memory: 512Mi
{{- end }}
