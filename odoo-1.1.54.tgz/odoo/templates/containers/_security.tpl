{{- define "odoo.container.security" }}
- name: security
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
  command:
    - login-server
  ports:
    - name: login
      containerPort: 8081
  readinessProbe:
    tcpSocket:
      port: 8081
    initialDelaySeconds: 5
    periodSeconds: 5
  envFrom:
    - configMapRef:
        name: odoo-config
    {{- include "odoo.secretsRef" . | nindent 4 }}
  volumeMounts:
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
    {{- /* security (login-server) gestiona tokens/sessions OEM en
           /home/odoo/.manager. Es uno de los 2 containers (junto con
           container-updater) que monta .manager — el resto de containers
           ni lo ven (defense in depth estructural, no por perms). */ -}}
    {{- include "odoo.volumeMount.odooManager" . | nindent 4 }}
    {{- /* security necesita src/.venv en RO: importa odoo_tools y otros
           módulos Python del runtime para validar tokens (mismo binario
           que login-server linkea contra el .venv compartido). NO escribe
           — solo lectura. */ -}}
    {{- include "odoo.volumeMount.odooSrc.ro" . | nindent 4 }}
{{- if and (ne .Values.Instance.Controller "oem") (eq .Values.Storage.Type "block") }}
    - name: odoo-data
      mountPath: /home/odoo/data
{{- end }}
    - name: backup-data
      mountPath: /home/odoo/backups
      subPath: "{{ .Values.Customer.Name }}/backups"
    - name: config-files
      mountPath: /home/odoo/.manager/config_files
    - name: pg-version
      mountPath: /etc/postgresql-common/default_version
      subPath: default_version
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      cpu: 1m
      memory: 32Mi
    limits:
      cpu: "1"
      memory: 2Gi
{{- end }}
