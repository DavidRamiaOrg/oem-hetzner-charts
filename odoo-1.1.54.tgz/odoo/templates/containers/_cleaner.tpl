{{- define "odoo.container.cleaner" }}
- name: cleaner
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
  command:
    - cleaner-service
  volumeMounts:
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
    {{- /* cleaner solo borra logs/sessions/tmp dentro de /home/odoo —
           src/.venv en RO defensivo. */ -}}
    {{- include "odoo.volumeMount.odooSrc.ro" . | nindent 4 }}
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      cpu: 1m
      memory: 16Mi
    limits:
      cpu: 100m
      memory: 128Mi
{{- end }}
