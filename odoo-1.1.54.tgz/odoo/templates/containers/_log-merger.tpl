{{/*
  Log-merger: sidecar lightweight que corre SOLO en el pod writer y
  recolecta los logs de las replicas extras (que escriben en EFS-shared
  `/home/odoo/logs/odoo-replica-N.log` con N>=1) inyectándolos en `odoo.log`.

  Cuándo se incluye:
    - `Storage.Type=network` o `Storage.Type=fsx` (EBS es RWO, no comparte
      logs entre pods).
    - `Odoo.Replicas > 0` — sólo las réplicas EXTRAS (13-OdooReader)
      escriben a archivos diferentes (`odoo-replica-N.log` para N>=1).
      Los pods con `replica-id="0"` (10-Odoo y 11-Cron) escriben todos
      al mismo `odoo.log` → sin necesidad de merger ahí.
      Si `Replicas=0` no hay nada que mergear independientemente del
      modo (single o multi) → skip.

  Por qué SOLO en el writer:
    - El output `odoo.log` debe tener un único escritor (el merger);
      el writer's odoo es el otro escritor del mismo archivo (writer's
      log natural). Two-writers a NFS local same-pod = OK por kernel
      O_APPEND serialization.
*/}}
{{- define "odoo.container.logMerger" }}
{{- if and (or (eq .Values.Storage.Type "network") (eq .Values.Storage.Type "fsx"))
            (gt (int .Values.Odoo.Replicas) 0) }}
- name: log-merger
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  command:
    - log-merger
  volumeMounts:
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
  resources:
    requests:
      cpu: "5m"
      memory: "16Mi"
    limits:
      cpu: "100m"
      memory: "64Mi"
{{- end }}
{{- end }}
