{{- define "odoo.container.odoo" }}
- name: odoo
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
  command:
    - system-init
  args:
    - "--mode=worker"
    - "--workers={{ .Values.Odoo.Workers }}"
    {{- $ws := int (.Values.Odoo.WebsocketWorkers | default 1) }}
    {{- if gt $ws 1 }}
    {{- $img := .Values.Images.Odoo.Version | toString }}
    {{- if and (regexMatch "^[0-9]+\\.[0-9]+\\.[0-9]+$" $img) (not (semverCompare ">=1.0.42" $img)) }}
    {{- fail (printf "Odoo.WebsocketWorkers=%d exige imagen odoo >= 1.0.42 (esta es %s): las anteriores no conocen ese flag, docopt aborta y el container no arranca" $ws $img) }}
    {{- end }}
    - "--websocket-workers={{ $ws }}"
    {{- end }}
    # El container `odoo` es HTTP-only siempre; cron vive en el container
    # `cron` (mismo pod en single, pod separado en multi).
    - "--cron-threads=0"
    - "--limit-memory-hard={{ .Values.Odoo.MemoryLimitHard }}"
    - "--limit-memory-soft={{ .Values.Odoo.MemoryLimitSoft }}"
    - "--limit-time-cpu={{ .Values.Odoo.CPULimit }}"
    - "--limit-time-real={{ .Values.Odoo.RealLimit }}"
  ports:
    - name: odoo
      containerPort: 8069
    # gevent (longpolling/websocket) corre en este container
    # (writer + replicas), no en `cron`.
    - name: gevent
      containerPort: 8072
  readinessProbe:
    exec:
      command:
        - cat
        - /var/run/odoo.status
    initialDelaySeconds: 5
    periodSeconds: 5
  envFrom:
    - configMapRef:
        name: odoo-config
    {{- include "odoo.secretsRef" . | nindent 4 }}
  env:
    # REPLICA_ID se lee del label `replica-id` del pod (downward API).
    # Pods primary (writer/base/cron) llevan replica-id="0"; extras "1","2",..
    # Si el label no existe, el env var queda vacío.
    - name: REPLICA_ID
      valueFrom:
        fieldRef:
          fieldPath: metadata.labels['replica-id']
    # POD_ROLE: writer | replica. Lo usa system-init para decidir si esperar
    # a que el mount-manager remontee tras un cambio en la image antes de
    # respawnar workers (solo en replicas; el writer escribe directo a RW).
    - name: POD_ROLE
      valueFrom:
        fieldRef:
          fieldPath: metadata.labels['role']
{{- /* PYTHONPYCACHEPREFIX (EFS) se define en el ConfigMap odoo-config y lo
       heredan todos los containers vía envFrom — un único cache compartido. */}}
{{- if .Values.PgBouncer.enabled }}
    # NO override de PGHOST aquí. PGHOST sigue apuntando al postgres real
    # (vía odoo-config ConfigMap = .Values.Postgres.Host). En su lugar,
    # PGBOUNCER_HOST se entrega como hint a system-init: éste lo inyecta
    # SOLO en el env de los workers HTTP (start_odoo_worker), no en gevent
    # ni en cron threads. Razón:
    #   - HTTP workers: queries cortas + transacciones → encaja en
    #     pgbouncer transaction mode (gran ratio de re-uso).
    #   - gevent (longpolling/bus.bus): hace LISTEN/NOTIFY → transaction
    #     mode rompe LISTEN (devuelve backend al pool tras cada txn) →
    #     debe ir DIRECTO a postgres.
    #   - cron threads (mismo container en single mode): LISTEN
    #     "cron_changes" + advisory locks → también directo a postgres.
    - name: PGBOUNCER_HOST
      value: "pgbouncer"
{{- end }}
  volumeMounts:
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
    {{- /* odoo container sirve HTTP — sólo LEE src/.venv (writes los hace
           jupyter / container-updater / jobs admin). Mount RO defensivo:
           writes accidentales fallan con EROFS. NO monta .manager. */ -}}
    {{- include "odoo.volumeMount.odooSrc.ro" . | nindent 4 }}
{{- if and (ne .Values.Instance.Controller "oem") (eq .Values.Storage.Type "block") }}
    - name: odoo-data
      mountPath: /home/odoo/data
{{- end }}
    - name: backup-data
      mountPath: /home/odoo/backups
      subPath: "{{ .Values.Customer.Name }}/backups"
    - name: pg-version
      mountPath: /etc/postgresql-common/default_version
      subPath: default_version
    - name: config-files
      mountPath: /home/odoo/.manager/config_files
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      {{- if .Values.Resources.Odoo.RequestCPU }}
      cpu: "{{ .Values.Resources.Odoo.RequestCPU }}"
      {{- end }}
      memory: "{{ .Values.Resources.Odoo.RequestRAM }}"
    limits:
      {{- if .Values.Resources.Odoo.LimitCPU }}
      cpu: "{{ .Values.Resources.Odoo.LimitCPU }}"
      {{- end }}
      memory: "{{ .Values.Resources.Odoo.LimitRAM }}"
{{- end }}
