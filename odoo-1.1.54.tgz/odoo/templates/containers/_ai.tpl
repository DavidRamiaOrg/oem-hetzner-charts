{{/*
  Contenedor `ai` — hospeda los asistentes de IA (OpenCode `serve` + el chat de
  Claude, claude-chat), SACÁNDOLOS del contenedor `jupyter`. Razón: jupyter es el
  terminal del cliente; con Claude/OpenCode ahí, el cliente podía leer las
  credenciales (tokens OAuth) de los devs. Aquí viven en /home/odoo/.ai, un
  subPath de odoo-base que jupyter NO monta → aislamiento estructural.

  Monta lo mismo que jupyter (código + home + backups + pg-version) MÁS:
    - /home/odoo/.ai      (odoo.volumeMount.odooAi)   — creds/estado IA.
    - /home/odoo/.ssh-key (odoo.volumeMount.aiSshKey) — SOLO id_rsa (deploy
      key del repo del usuario) para `git push`; sin odoo_enterprise.
  NO monta .manager (eso es del login-server).

  Sólo en oem + staging (los asistentes IA son staging-only). Los puertos
  opencode (8889) y claude (8890, claude-chat) viven aquí; la Service `jupyter`
  los enruta por named port (mismo pod).

  command `ai-start` (entrypoint de la imagen odoo): arranca `opencode serve`
  + `claude-login-broker restore` y mantiene vivo el contenedor. CLAUDE_CONFIG_DIR
  y el data dir de OpenCode apuntan a /home/odoo/.ai.
*/}}
{{- define "odoo.container.ai" }}
{{- if and (eq .Values.Instance.Controller "oem") (eq .Values.Odoo.Stage "staging") }}
- name: ai
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
  command:
    - ai-start
  lifecycle:
    preStop:
      exec:
        # Al apagar el pod: para el chat de Claude conservando su estado, para que
        # ai-start lo vuelva a arrancar. Ver claude-login-broker `shutdown` vs `stop`.
        command: ["claude-login-broker", "shutdown"]
  ports:
    - name: opencode
      containerPort: 8889
    # claude-chat (the Claude chat window), started per connect by claude-login-broker.
    - name: claude
      containerPort: 8890
  readinessProbe:
    tcpSocket:
      port: 8889
    initialDelaySeconds: 10
    periodSeconds: 10
  envFrom:
    - configMapRef:
        name: odoo-config
    {{- include "odoo.secretsRef" . | nindent 4 }}
  volumeMounts:
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
    {{- include "odoo.volumeMount.odooSrc" . | nindent 4 }}
    {{- include "odoo.volumeMount.odooAi" . | nindent 4 }}
    {{- include "odoo.volumeMount.aiSshKey" . | nindent 4 }}
    - name: backup-data
      mountPath: /home/odoo/backups
      subPath: "{{ .Values.Customer.Name }}/backups"
    - name: backup-data
      mountPath: /tmp
      subPath: "{{ .Values.Customer.Name }}/tmp"
    - name: pg-version
      mountPath: /etc/postgresql-common/default_version
      subPath: default_version
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      cpu: 1m
      memory: 32Mi
    limits:
      cpu: "1000m"
      memory: "3Gi"
{{- end }}
{{- end }}
