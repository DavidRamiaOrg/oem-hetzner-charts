{{- define "odoo.container.jupyter" }}
- name: jupyter
  image: "{{ .Values.Images.Odoo.Image }}:{{ .Values.Odoo.Version }}-{{ .Values.Images.Odoo.Version }}{{- with .Values.Images.Odoo.Branch }}-{{ . }}{{- end }}"
  # Terminal del cliente: envuelto en un shell que borra las env vars
  # KUBERNETES_* (residuo que enableServiceLinks:false NO quita — las inyecta
  # siempre el kubelet para el API server) antes de arrancar jupyter-lab, para
  # que el cliente no vea el entorno de Kubernetes.
  command:
    - bash
    - -c
    - |
      unset $(env | grep -oE '^KUBERNETES_[A-Za-z0-9_]+')
      exec jupyter-lab --path="$JUPYTER_PATH" {{- if eq .Values.Instance.Controller "self" }} --password="$JUPYTER_PASSWORD" {{- end }}
  ports:
    # OpenCode + Claude RC moved to the dedicated `ai` container (see _ai.tpl):
    # jupyter is the client's terminal and must not see their credentials.
    # The `opencode` port (8889) now lives in `ai`.
    - name: jupyter
      containerPort: 8888
  readinessProbe:
    tcpSocket:
      port: 8888
    initialDelaySeconds: 10
    periodSeconds: 10
  envFrom:
    - configMapRef:
        name: odoo-config
    {{- include "odoo.secretsRef" . | nindent 4 }}
  volumeMounts:
    {{- include "odoo.volumeMount.odooBase" . | nindent 4 }}
    {{- /* jupyter edita código (modules, .py) y pip-installa al .venv —
           junto con container-updater el RW real sobre src/.venv. No monta
           .manager (queda fuera del subPath=odoo). */ -}}
    {{- include "odoo.volumeMount.odooSrc" . | nindent 4 }}
{{- if and (ne .Values.Instance.Controller "oem") (eq .Values.Storage.Type "ebs") }}
    - name: odoo-data
      mountPath: /home/odoo/data
{{- end }}
    - name: backup-data
      mountPath: /home/odoo/backups
      subPath: "{{ .Values.Customer.Name }}/backups"
    - name: backup-data
      mountPath: /tmp
      subPath: "{{ .Values.Customer.Name }}/tmp"
    - name: pg-version
      mountPath: /etc/postgresql-common/default_version
      subPath: default_version
  imagePullPolicy: "{{- if eq .Values.Odoo.Stage "production" }}IfNotPresent{{- else }}Always{{- end }}"
  resources:
    requests:
      cpu: 1m
      memory: 32Mi
    limits:
      cpu: "1000m"
      memory: "3Gi"
{{- end }}
