{{- define "odoo.container.pgbouncer" }}
{{- if .Values.PgBouncer.enabled }}
{{- $maxClientConn := mul (int .Values.Odoo.Workers) (int .Values.Odoo.MaxDBConn) }}
- name: pgbouncer
  image: "{{ .Values.PgBouncer.Image }}"
  env:
    - name: PGBOUNCER_DATABASE
      value: "{{ .Release.Namespace }}"
    - name: POSTGRESQL_HOST
      value: "postgres"
    - name: POSTGRESQL_USERNAME
      value: "{{ .Release.Namespace }}"
    - name: POSTGRESQL_PASSWORD
    {{- if eq .Values.Instance.Controller "oem" }}
      valueFrom:
        secretKeyRef:
          name: odoo-secrets
          key: PGPASSWORD
    {{- else }}
      valueFrom:
        configMapKeyRef:
          name: odoo-secrets
          key: PGPASSWORD
    {{- end }}
    - name: PGBOUNCER_POOL_MODE
      value: "transaction"
    - name: PGBOUNCER_DEFAULT_POOL_SIZE
      value: "{{ max (div (mul $maxClientConn (int .Values.PgBouncer.PoolPercent)) 100) 1 }}"
    - name: PGBOUNCER_MAX_CLIENT_CONN
      value: "{{ $maxClientConn }}"
    - name: PGBOUNCER_IGNORE_STARTUP_PARAMETERS
      value: "extra_float_digits"
  ports:
    - name: pgbouncer
      containerPort: 5432
  readinessProbe:
    tcpSocket:
      port: 5432
    initialDelaySeconds: 3
    periodSeconds: 5
  imagePullPolicy: "Always"
  resources:
    requests:
      cpu: 10m
      memory: 32Mi
    limits:
      cpu: 200m
      memory: 64Mi
{{- end }}
{{- end }}
