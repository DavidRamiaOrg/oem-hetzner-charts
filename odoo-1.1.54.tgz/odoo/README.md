# Odoo Helm Chart

Deploys a complete Odoo instance on Kubernetes with reverse proxy, monitoring, backups, and GitOps lifecycle management via ArgoCD. Supports both **OEM** (centrally managed) and **self-hosted** controller modes.

**Chart version**: 1.1.37

## Controller Modes

The chart supports two controller modes set via `Instance.Controller`:

| Mode | Description |
|------|-------------|
| `oem` | Centrally managed by the OEM module. Secrets stored in `Secret`. Jobs gated by `controller=="oem"`. |
| `self` | Self-hosted / standalone. Secrets stored in `ConfigMap`. Self jobs (`30`-`36`) gated by `controller=="self"`; the init→run transition is status-driven via `ArgoGateway` (the old post-install Helm hook was removed). |

The `INSTANCE_CONTROLLER` environment variable is injected into all ConfigMaps so scripts can branch behavior at runtime. The `providers/_common.tpl` provides the `odoo.secretsRef` helper which returns `Secret` for OEM mode and `ConfigMap` for self mode.

## Pod Modes

The `Instance.Pods` value controls pod topology:

| Mode | Description |
|------|-------------|
| `single` | All containers run in a single pod (default). Service selectors target the combined pod. |
| `multi` | Containers are split across multiple pods. Service selectors are conditional on the pod mode. |

## Architecture

```
                       ┌──────────────────────────────────────────────────────────────────────────┐
                       │                          Namespace (per instance)                        │
                       │                                                                          │
  ┌──────────┐         │  ┌────────────────────────────────────────────────────────────────────┐  │
  │ Ingress  ├Ingress──┼─►│                       nginx (Deployment)                          │  │
  └──────────┘         │  │                  reverse proxy + auth_request                     │  │
                       │  │       odoo:8069, gevent:8072, security:8081, jupyter:8888         │  │
                       │  └────────────────────────────────┬───────────────────────────────────┘  │
                       │                                   │                                      │
                       │  ┌────────────── 10-Odoo (writer in single, base replica in multi) ───┐  │
                       │  │                                ▼                                   │  │
                       │  │  odoo(8069,8072) | metrics | security                              │  │
                       │  │  + (single only) cron | jupyter | ai* | cleaner | updater | alloy  │  │
                       │  │  + log-merger* | pgbouncer*                                        │  │
                       │  └────────────────────────────────────────────────────────────────────┘  │
                       │  ┌────────────── 11-Cron (multi mode only — writer) ──────────────────┐  │
                       │  │  cron | jupyter | ai* | cleaner | updater | metrics | alloy        │  │
                       │  │  + log-merger*                                                     │  │
                       │  └────────────────────────────────────────────────────────────────────┘  │
                       │  ┌────────────── 13-OdooReader-{1..N} (extras, EFS/FSx) ─────────────┐  │
                       │  │  odoo(8069,8072) | metrics | security                              │  │
                       │  │  + pgbouncer*                                                      │  │
                       │  └────────────────────────────────────────────────────────────────────┘  │
                       │                                                                          │
                       │  ┌─── Volumes ──────────────────────────────────────────────────────┐    │
                       │  │  EBS:  odoo-base (RWO) | odoo-data (RWO, self only)              │    │
                       │  │  FSX:  odoo-data-fsx (RWX, shared FSx Lustre + subPath)          │    │
                       │  │  EFS:  odoo-data-efs (RWX, EFS AP) + odoo-src (RWX, csi-loop)    │    │
                       │  │  Backup: backup-data (S3 CSI in self / hostPath in oem)          │    │
                       │  └──────────────────────────────────────────────────────────────────┘    │
                       └──────────────────────────────────────────────────────────────────────────┘
```

(* = sidecar conditional on `Storage.Type=efs/fsx`, `PgBouncer.enabled`, replica presence, or — for `ai` — `Instance.Controller=oem` + `Odoo.Stage=staging`. EFS-only volume mounts for `/home/odoo/src` and `/home/odoo/.venv` are served by the cluster-wide **csi-loop** CSI driver from two direct-mounted PVCs (`odoo-src`, `odoo-venv`). In OEM, `/home/odoo` is mounted as subPath `odoo` and `/home/odoo/.manager` as subPath `.manager` of the base PVC on **all** storage types — the EFS Access Point on efs, the EBS/FSx volume otherwise.)


Nginx routes traffic to backend Services by name: `odoo:8069` (HTTP backend, may load-balance across writer + replicas in `single` mode or replicas in `multi` mode), `gevent:8072` for `/websocket` and `/longpolling` (every odoo container runs its own gevent process), `security:8081` for login-server (replicated, any pod can validate), and `jupyter:8888` for JupyterLab (writer-only). The main `location /` does not pass `Upgrade`/`Connection` headers — websocket traffic is handled exclusively by the gevent service.

## Instance Lifecycle

The chart behavior is driven by `Instance.Status` for **both** controller modes. Each status creates different resources:

| Status | Resources Created | Purpose | Modes |
|--------|------------------|---------|-------|
| `init` | Job `system-prepare` | First-run: clone repos, create DB, install requirements | self + oem |
| `run` | Deployment `odoo` + `nginx`, Services, Ingress | Normal operation | self + oem |
| `post-migration` | Same as `run` | Running after migration | oem only |
| `migration` | Job `migrate-odoo`, ConfigMap `odoo-config-migration` | Upgrade via upgrade.odoo.com | oem only |
| `rebuild` | Job `rebuild-staging` | Rebuild staging from production | oem only |
| `restore` | Job `restore-backup` | Restore from backup file | oem only |
| `system_down` | Deployment `nginx` + Services + Ingress (odoo/cron not rendered → scaled to zero) | Idle suspend: nginx wakes the instance back to `run` on the next request | oem staging only |
| `to_delete` | Namespace + PVCs + StorageClass + `oem-events` RBAC + Certificates + the `final-backup` Job | Soft delete (1-day grace period, extended while the final backup runs) | oem only |

### init → run transition (both modes)

When deployed with `Instance.Status: "init"` the chart only renders the `system-prepare` Job. When that Job finishes successfully it patches the ArgoCD Application via the `ArgoGateway` HTTP API, flipping `Instance.Status` to `run`. ArgoCD re-syncs and the workloads (`odoo`, `cron`, ingress, services) come up. This applies to **self mode** as well: the post-install Helm hook used by the previous chart version has been removed in favour of the status-driven flow.

Required values for the transition (both modes):
- `ArgoGateway.Url` — HTTP URL of the gateway pod (e.g. `http://argo-gateway.<ns>.svc.cluster.local:8080`).
- `ArgoGateway.Secret` — `sha256(GATEWAY_ADMIN_SECRET)` of the gateway.
- `ArgoGateway.Token` — per-instance app token registered on the gateway.

In OEM mode KubeManager fills these automatically. In self mode the operator must populate them in the chart values.

### Soft delete (oem only)

When `Instance.Status` is set to `to_delete`, the workloads are pruned by ArgoCD but the tenant's state is NOT. What REMAINS is: Namespace (`01`), Storage (`04-Storage`, which has no `Instance.Status` gate at all), the `oem-events` SA/Role/RoleBinding (`04-EventsRBAC`), the domain Certificates (`18-Certificates`), **the Secrets (`02`) and the `odoo-config` / `odoo-config-files` ConfigMaps (`03`)**, plus the `final-backup` Job (`23`) and the CleanData post-delete hook (`22`). Everything else (Deployments, Services, Ingresses, Snapshots, the other Jobs, Grafana, Prometheus) stops rendering, and ArgoCD's `prune: true` + `selfHeal: true` deletes the orphans. All of it goes for good with the cascade when the Application is finally deleted.

Secrets and ConfigMaps used to be pruned here too. They are kept so `23-FinalBackup` can take the last backup with the ordinary `envFrom` and the ordinary `odoo.volumes` — including the tenant's own `PGPASSWORD`, which cannot be interpolated from `.Values` at all (it is re-randomised on every render and only stays put in the cluster because of the Application's `ignoreDifferences`). The backup works because the PVCs and the database are still there: the database is only dropped by the CleanData hook, at purge time.

The one exception is **`odoo-instance-values`, which is still pruned**: its DISAPPEARANCE is the de-registration signal that kube_manager's `InstanceValuesCache` consumes by watch, the equivalent of the Application's `deletionTimestamp`. Keeping it would leave the build counting as live until the purge.

The controller sets this state via PATCH (not DELETE) and records the timestamp in the `odoo-kube-manager/to-delete-at` annotation. A background purge thread (only in `oem-reporter`) permanently deletes the ArgoCD Application (and thus the namespace) after a 1-day grace period — and, since kube_manager 1.0.40, it postpones that deletion while the final backup is still reporting progress, up to a hard cap.

### Idle suspend (oem staging only)

When `Instance.IdleSuspend > 0` (default `360` minutes = 6h) on an **OEM staging** instance, the nginx container tracks idle time and flips the ArgoCD Application `Instance.Status` between `run` and `system_down` via the `ArgoGateway` (same path as the dashboard's manual shutdown/start). In `system_down` the `odoo`/`cron` Deployments stop rendering (scaled to zero) while `nginx`, Services and Ingress stay up; the next incoming request makes nginx flip the status back to `run`. Driven entirely by `Instance.IdleSuspend` (`0` = disabled, no separate flag); requires `ArgoGateway.Url` to be set.

### Always-rendered resources

Independent of `Instance.Status` (except `to_delete`): Secrets, ConfigMaps, PVCs, StorageClass, Snapshots, Services, NetworkPolicy, Grafana dashboard, ServiceMonitor.

Self-only jobs (`30`-`36`) are still further guarded by `Instance.Controller=="self"`.

## Templates

Templates are numbered with logical grouping. Container templates live in `containers/` subfolder. Provider-specific helpers live in `providers/` subfolder. All extensions normalized to `.yaml`.

### Provider System

The old `_helper.tpl` has been replaced by a provider-based architecture in the `providers/` subfolder:

| File | Purpose |
|------|---------|
| `providers/_common.tpl` | Provider-agnostic helpers: `odoo.imageRegistryCredentials`, `odoo.nodeSelector`, `odoo.secretsRef`, `odoo.volumes`, and the routing predicates `odoo.ingress.cloudfrontTraefik` / `.jupyter` |
| `providers/_eks.tpl` | AWS EKS provider — defines `odoo.provider.eks.*` helpers |
| `providers/_hetzner.tpl` | Hetzner provider — defines `odoo.provider.hetzner.*` helpers |

There is no dispatcher layer. Templates call provider-specific helpers directly using `printf`:

```
{{ include (printf "odoo.provider.%s.helperName" .Values.K8S.Provider) . }}
```

Each provider file defines these helpers: `s3PVDefinition`, `s3PVCDefinition`, `scDefinition`, `snapshotDefinition`, `jupyterServiceAnnotations`, `nginxServiceAnnotations`, `odooIngressAnnotations`, `customIngressAnnotations`, `jupyterIngressAnnotations`. The EKS provider additionally defines `scDefinitionEfs` (the EFS Access Point StorageClass, also reused by `MigrateStorage`).

Adding a new provider requires creating `providers/_newprovider.tpl` with the same `define` names following the `odoo.provider.<name>.*` naming convention.

| Range | Group | Templates |
|-------|-------|-----------|
| 01-05 | Infrastructure | Namespace, Secrets, ConfigMaps, Storage, Snapshots |
| 10-14 | Deployments | Odoo, Cron, Nginx, OdooReader (extras), NginxReader (extras) |
| 15-18 | Networking | Services, Ingress, CustomIngress, Certificates |
| 20-22 | Common jobs | SystemPrepare, ServiceContainer, CleanData |
| 25-28 | OEM / migration jobs | Migration, Rebuild, Restore, MigrateStorage (one-shot ebs/fsx → efs) |
| 30-36 | Self jobs | Backup, ImportDatabase, UpdateSources, StagingRebuild, RestoreBase, RestoreData, RestoreDatabase |
| 40-41 | Monitoring | Grafana, Prometheus |

### Template Details

| File | Kind | Name | Condition |
|------|------|------|-----------|
| `01-Namespace` | Namespace | `{{ .Release.Namespace }}` | Always |
| `02-Secrets` | Secret/ConfigMap (x3) | `odoo-secrets` (Secret in OEM / ConfigMap in self via `odoo.secretsRef`) with `PGPASSWORD`, `JUPYTER_PASSWORD` and `LONGOP_SECRET` (since 1.1.30 — see [Long-op signing key](#long-op-signing-key)), `ssh-keys`, `odoo-admin-secrets` | Not OEM to_delete |
| `03-ConfigMaps` | ConfigMap (x3-4) | `odoo-instance-values`, `odoo-config` (includes `INSTANCE_CONTROLLER`), `odoo-config-files`, `odoo-config-migration`* | Not OEM to_delete (*migration only) |
| `04-Storage` | PV + PVC + StorageClass | `backup-data` (S3), per-backend base PVC (`odoo-base` for EBS, `odoo-data-fsx` for FSx, `odoo-data-efs` for EFS), `odoo-data` (EBS self only), `odoo-src` + `sc-<ns>-csi-loop` (EFS only) | Always (variants depend on `Storage.Type` / `MigrateStorage`) |
| `05-Snapshots` | VolumeSnapshotClass + SnapshotSchedule (x3) | daily/weekly/monthly | `Storage.Type=ebs` + `Snapshots.Type=k8s`, not OEM to_delete (the 3 schedules are production-only) |
| `10-Odoo` | Deployment | `odoo` — single: writer (everything except 11-Cron, incl. `ai` on oem+staging); multi: base replica (HTTP-only). When `Storage.Type=efs` the pod mounts the csi-loop PVCs `odoo-src` + `odoo-venv` (RW in single, RO in multi) at `/home/odoo/src` and `/home/odoo/.venv`. In OEM `/home/odoo` is subPath `odoo` and `/home/odoo/.manager` is subPath `.manager` of the base PVC (all storage types). | run/post-migration |
| `11-Cron` | Deployment | `cron` — multi mode only. Cron + jupyter + ai (oem+staging) + cleaner + updater + metrics + alloy + log-merger (no `security`/`pgbouncer` — those live only in the pods with the `odoo` container). | run/post-migration, multi pod mode |
| `12-Nginx` | Deployment | `nginx` | Active (not OEM to_delete) |
| `15-Services` | Service (8-10) + NetworkPolicy | `postgres` (ExternalName), `nginx`, `odoo`, `gevent` (8072), `security` (8081), `jupyter` (8888), `monitoring`, `memory-monitoring`, `cron-memory-monitoring` (multi only), `pgbouncer` (when `PgBouncer.enabled`), `instance-isolation` | Not OEM to_delete (selectors conditional on Pods mode) |
| `16-Ingress` | Ingress | `odoo` (+ `jupyter` in self mode) | Not to_delete, and (oem or `Instance.Active`) |
| `17-CustomIngress` | Ingress (per domain) | `custom-domain-*` — TLS via explicit `alb certificate-arn` when the domain's ACM ARN is known (`.Arn`), else ACM hostname auto-discovery. Both are dropped under CloudFront + Traefik (see [Ingress](#ingress)) | CustomDomains |
| `18-Certificates` | Secret / Certificate | **manual**: one shared tls Secret per cert (`Odoo.Certificates`, materialised once in the prod ns, annotated for aws-cert-manager → ACM). **auto**: a per-domain cert-manager `Certificate` (Let's Encrypt). One cert can cover N domains. | CustomDomains / Certificates |
| `20-SystemPrepare` | Job | `system-prepare` | init (both modes) |
| `21-ServiceContainer` | CronJob | `service-container` | run/post-migration |
| `22-CleanData` | Job | `clean-data-*` (in `default` ns) | Helm post-delete hook |
| `23-FinalBackup` | Job | `final-backup` — last full backup (DB + filestore) before the instance is purged for good. Runs `make-backup --format=zip` with no `--file-name`, so the name is the standard `backup_<db>_<date>.tar.gz` and no `now` ends up in the template (a Job's `spec.template` is immutable). Mounts the sources as a csi-loop REPLICA: it only reads. No `ttlSecondsAfterFinished` — with a TTL, Kubernetes deletes the finished Job and ArgoCD's selfHeal recreates it, backing up in a loop. | to_delete, OEM only |
| `25-Migration` | Job | `migrate-odoo` | migration/post-migration, OEM only |
| `26-Rebuild` | Job | `rebuild-staging` | rebuild, OEM only |
| `27-Restore` | Job | `restore-backup` | restore, OEM only |
| `28-MigrateStorage` | Job | `migrate-storage-efs` — one-shot migration of `/home/odoo` from `ebs`/`fsx` to `efs` (EFS AP + csi-loop). See [MigrateStorage](#migratestorage). | `MigrateStorage=efs` and `Storage.Type!=efs` |
| `30-Backup` | CronJob | `create-backup` | Self only (schedule `0 0 31 2 0`, `suspend: true` — triggered on demand) |
| `31-ImportDatabase` | CronJob | `import-database` | Self only (schedule `0 0 31 2 0`, `suspend: true` — triggered on demand) |
| `32-UpdateSources` | CronJob | `update-sources` | Self only (schedule `0 0 31 2 0`, `suspend: true` — triggered on demand) |
| `33-StagingRebuild` | CronJob | `staging-rebuild` | Self, `Odoo.Stage=staging` + `Source.Name` (schedule `0 0 31 2 0`, `suspend: true` — triggered on demand) |
| `34-RestoreBase` | VolumeSnapshotClass + VolumeSnapshotContent + VolumeSnapshot + PVC (`odoo-base-restored`) + Job | `restore-odoo-base` | Self, not `Instance.Active` + `Instance.BaseRestore` |
| `35-RestoreData` | VolumeSnapshotClass + VolumeSnapshotContent + VolumeSnapshot + PVC (`odoo-data-restored`) + Job | `restore-odoo-data` | Self, not `Instance.Active` + `Instance.DataRestore`, `Storage.Type!=efs` |
| `36-RestoreDatabase` | Job | `restore-database` | Self only |
| `13-OdooReader` | Deployment (×N) | Extra HTTP replicas: `odoo-replica-1..N` | EFS/FSx, when `Odoo.Replicas>0` |
| `14-NginxReader` | Deployment (×N) | Nginx paired 1-to-1 with each `odoo-replica-N` (same node via podAffinity) | EFS/FSx, when `Odoo.Replicas>0` |
| `40-Grafana` | ConfigMap | `odoo-dashboard` (uid: sha256 of namespace, max 40 chars). Node Resources row conditional on `K8S.NodeType=="dedicated"` | Not OEM to_delete |
| `41-Prometheus` | ServiceMonitor (x2) | `odoo-metrics`, `odoo-memory-metrics` | Not OEM to_delete |
| `42-PodDisruptionBudget` | PDB (x2-3) | `odoo`, `nginx` (+ `cron` in multi) — `minAvailable=1` on the primary pods. See [Node disruption](#node-disruption-karpenter). | **EFS/FSx only**, Active (not OEM to_delete) |

## Pod Containers

Containers are grouped per pod role. All odoo-image pods use `shareProcessNamespace: true` so sidecars can see each other's processes (required for metrics, watchdogs, etc.).

| Container | Image | Command | Port | Purpose | Pods |
|-----------|-------|---------|------|---------|------|
| `odoo` | odoo | `system-init --mode=worker` | 8069 (http), 8072 (gevent) | HTTP workers + gevent (longpolling/websocket). Spawned in every pod with odoo. | writer + replicas |
| `cron` | odoo | `system-init --mode=cron` | — | Cron threads + SMTP (non-production). Single instance per deploy. | writer (single: same pod; multi: 11-Cron pod) |
| `jupyter` | odoo | `jupyter-lab` | 8888 | JupyterLab with Odoo/PostgreSQL kernels. Single instance per deploy (writer pod). The client's terminal — does **not** host Claude/OpenCode (moved to `ai`) so the client cannot read the devs' credentials. | writer |
| `ai` | odoo | `ai-start` | 8889 (opencode) | **OEM + staging only.** Hosts OpenCode `serve` + Claude Remote Control, split out of `jupyter`. Mounts the code + a private `.ai` subPath (creds/state, **not** mounted in jupyter) + **only** `id_rsa` (git push). Runs in the writer pod; the `jupyter` Service routes its 8889 port here by named port. | writer (staging) |
| `security` | odoo | `login-server` | 8081 | Token auth + session validation. Replicated in every pod with odoo so nginx can balance auth_request. | writer + replicas |
| `cleaner` | odoo | `cleaner-service` | — | Hourly logrotate + tmp cleanup. | writer |
| `container-updater` | odoo | `sleep infinity` (OEM) / `update-odoo` (self) | — | OEM: exec target for on-demand updates; Self: weekly scheduled updates. | writer |
| `log-merger` | odoo | `log-merger` | — | EFS/FSx with extra replicas. Reads `odoo-replica-*.log` and writes to `odoo.log` in the writer pod (inode-tracked dual writer with the writer's own odoo). | writer (only when `Storage.Type=efs/fsx` AND `Replicas>0`) |
| `metrics` | odoo | `metrics-server` | 9191 | Prometheus RSS exporter. | writer + replicas |
| `alloy` | alloy | (default) | 9100 | Log forwarding + metrics. | writer (single: alloy in 10-Odoo; multi: alloy in 11-Cron) |
| `pgbouncer` | custom Alpine | entrypoint.sh | 5432 | Connection pooling (transaction mode). Optional, enabled via `PgBouncer.enabled`. | every pod with the `odoo` container (single: writer; multi: base replica; + `13-OdooReader` extras). Not in the `11-Cron` writer. |

## Resource Management

Container resources for `odoo` and `cron` are computed dynamically by the OEM module based on the project's `memory_limit` setting (default 1024 Mi), worker count, and stage. The OEM passes pre-calculated `Resources.Odoo.*` and `Resources.Cron.*` values through build_data to the Controller, which forwards them to the Helm chart.

### Formulas

Given `hard = memory_limit` (per worker, in bytes) and `soft = hard * 0.8`:

Given `cpu_request` (project setting, default 500 millicores):

| | Production | Staging |
|---|---|---|
| **CPU request** | `cpu_request`m per worker (odoo) / `cpu_request`m (cron) | `cpu_request/2`m per worker (odoo) / `cpu_request/2`m (cron) |
| **CPU limit** | `workers * 1000`m (odoo) / `1000`m (cron) | `workers * 1000`m (odoo) / `1000`m (cron) |
| **RAM request** | `soft * 0.8 * N` | `soft * 0.6 * N` |
| **RAM limit** | `max(hard * 0.8 * N, hard)` | `max(hard * 0.6 * N, hard)` |

Where `N` = number of workers for the odoo container, `N` = 1 for the cron container.

CPU limits are set to 1 core per worker for the odoo container (covers HTTP workers + gevent) and 1 core fixed for the cron container. `Odoo.MemoryLimitHard` and `Odoo.MemoryLimitSoft` are passed as Helm values so the Odoo process enforces its own per-worker memory limits.

### nginx container

Fixed in the chart (`containers/_nginx.tpl`), not computed by OEM: `10m`/`64Mi` requests, `500m`/`512Mi` limits. The memory **request** went from `8Mi` to `64Mi` in 1.1.30 — a container measured at ~18 MiB at rest was permanently above its request, which makes it the *first* candidate the kubelet evicts under node memory pressure, and evicting nginx takes the whole tenant's ingress down since it is the only way in. 64Mi also absorbs the `lua_shared_dict` of the long-op chain (64m declared, a few KiB resident while idle) becoming resident as it fills. The 512Mi limit is unchanged on purpose: it is comfortable for baseline + shared dict + body buffers, and must not be raised to paper over an oversized `client_body_buffer_size` in the nginx image.

## Storage

Storage layout depends on the `Storage.Type` (`ebs` / `fsx` / `efs`) and on the controller mode (`oem` / `self`). Since chart 1.1.12 the home layout is **unified across all three types**: the base PVC is mounted as **subPath `odoo`** at `/home/odoo`, with OEM `.manager` (and `.ai`) as sibling subPaths (see the note further down). ⚠️ Instances created **before** 1.1.12 on `ebs`/`fsx` have their data at the volume **root** (not under `odoo/`) and need a one-time data migration before upgrading. The base PVC name is computed by the `odoo.odooBaseClaimName` helper:

| `Storage.Type` | Base PVC name | Access | Backing |
|----------------|---------------|--------|---------|
| `ebs` (default) | `odoo-base` | RWO | EBS gp3 via per-namespace `sc-<ns>` |
| `fsx` | `odoo-data-fsx` | RWX | Static PV against a shared FSx for Lustre + kubelet subPath |
| `efs` | `odoo-data-efs` | RWX | EFS Access Point via per-namespace `sc-<ns>-efs` |

Across controller modes:

- **OEM mode**: a single base PVC (labelled `backup: "true"`). `/home/odoo/data` is a regular directory inside it (no separate `odoo-data` PVC). Backup storage uses **hostPath** volumes pointing to `/mnt/s3/<bucket>/<customer>/backups` and `/mnt/s3/<bucket>/<customer>/tmp` (mounted by a DaemonSet in the `odoo-env-manager` chart via Mountpoint for S3). No S3 CSI PV/PVC per instance.
- **Self mode**: the base PVC + an extra `odoo-data` block PVC for filestore (EBS only — for `efs`/`fsx` the filestore lives inside the shared base PVC) + an S3 CSI PVC `backup-data` with subPath per customer.

For `Storage.Type=efs` the chart **also** provisions two csi-loop PVCs — `odoo-src` (source tree) and `odoo-venv` (Python venv) — see the [EFS section](#storagetypeefs-multi-pod-shared-filesystem) below.

| Volume | Driver | Access | Default Size | Content | Mode |
|--------|--------|--------|-------------|---------|------|
| `odoo-base` (ebs) / `odoo-data-fsx` (fsx) / `odoo-data-efs` (efs) | EBS gp3 / FSx Lustre / EFS AP | RWO / RWX / RWX | `Storage.Base` (6Gi); efs hardcoded 50Gi | Source code, venv, config, logs, SSH keys (+ data in OEM). Home is mounted as subPath `odoo`; OEM `.manager`/`.ai` are sibling subPaths. On efs, `src`/`.venv` live in the csi-loop PVCs instead. | Both |
| `odoo-data` | Block volume (e.g., EBS gp3) | ReadWriteOnce | `Storage.Data` (4Gi) | Filestore, sessions | Self only, EBS only |
| `odoo-src` | csi-loop (`loop-image.csi.processcontrol.io`) | ReadWriteMany | `Storage.EFS.SrcSize` (15Gi, online-resizable) | `/home/odoo/src` (direct mount) | EFS only |
| `odoo-venv` | csi-loop (same SC as `odoo-src`) | ReadWriteMany | `Storage.EFS.VenvSize` (5Gi, online-resizable) | `/home/odoo/.venv` (direct mount) | EFS only |
| `backup-data` | hostPath (OEM) / S3 CSI (Self) | — / ReadWriteMany | — / 50Gi | Backup files | Both |
| `temp-data` | hostPath | — | — | Temporary files (`/tmp`) | OEM only |

### EBS Snapshots (production only)

| Schedule | Frequency | Retention |
|----------|-----------|-----------|
| `daily-snapshots` | Every 6h (03:00, 09:00, 15:00, 21:00) | 7 days |
| `weekly-snapshots` | Sunday 06:00 | 28 days |
| `monthly-snapshots` | 1st of month 07:00 | 365 days |

### `Storage.Type=efs` (multi-pod shared filesystem)

When `Storage.Type=efs` the chart provisions **three** RWX PVCs that work together — all backed by the same EFS filesystem (`Storage.EFS.Filesystem`):

| PVC | StorageClass | Driver | Mounted at | Holds |
|-----|--------------|--------|------------|-------|
| `odoo-data-efs` | `sc-<ns>-efs` (EFS AP, `uid:999, gid:999, directoryPerms:770`) | `efs.csi.aws.com` | `/home/odoo` (subPath `odoo`), `/home/odoo/.manager` (subPath `.manager`, OEM only) | Filestore, sessions, logs, config, SSH keys, customer data, OEM manager/login-server tokens |
| `odoo-src` | `sc-<ns>-csi-loop` (provisioner `loop-image.csi.processcontrol.io`, `allowVolumeExpansion: true`) | csi-loop (cluster-wide, see [`csi-loop` chart](../csi-loop/)) | `/home/odoo/src` (**direct mount, no subPath**) | Source code (odoo/enterprise/custom) — small-files + mmap-heavy, benefits from native ext4 |
| `odoo-venv` | `sc-<ns>-csi-loop` (same SC as `odoo-src`) | csi-loop | `/home/odoo/.venv` (**direct mount, no subPath**) | Python virtualenv |

The PVCs are wired in `providers/_common.tpl`: `odoo.volumeMount.odooBase` (base PVC, subPath `odoo` — same on **all** storage types), `odoo.volumeMount.odooManager` + `odoo.volumeMount.odooAi` (base PVC, subPaths `.manager` / `.ai`, OEM — all storage types), and `odoo.volumeMount.odooSrc[.ro]` (the two csi-loop PVCs, **direct mounts** + `mountPropagation: HostToContainer`).

**Why two separate csi-loop PVCs (and no subPath)?** `replicaMode=overmount` (the default) refreshes a replica by over-mounting a fresh ext4 image on the driver's target (an `MS_SHARED` anchor). That over-mount propagates into the consumer container only if the container's mount is a slave of the anchor (`mountPropagation: HostToContainer`) **and** is a direct mount — a kubelet `subPath` bind is created `MS_PRIVATE`, so propagation never reaches it and the replica stays pinned to the old image. Splitting `src` and `.venv` into two PVCs lets each mount directly at its own path. (FUSE mode does not need this, but the chart standardises on the layout that works for both.)

**csi-loop driver — how the source tree stays in sync between writer and replicas**

`odoo-src` and `odoo-venv` are served by the cluster-wide **csi-loop** CSI driver (installed via the separate `csi-loop` chart). The driver stores **one ext4 image file per PVC** on the same EFS filesystem and exposes each as a filesystem to the pods that mount it. The role (writer or replica) is decided automatically from the volume entry's `persistentVolumeClaim.readOnly` flag:

- **Writer pod** (`persistentVolumeClaim.readOnly` not set — `10-Odoo` in single mode, `11-Cron` in multi mode): csi-loop mounts each ext4 image **RW directly** on its target. Writes from `git fetch`, jupyter, `pip install`, etc. land natively in ext4 and are flushed to EFS every `Storage.EFS.WriterSyncInterval` (default `1s`).
- **Replica pod** (`persistentVolumeClaim.readOnly: true` — `10-Odoo` base in multi mode, `13-OdooReader` extras): csi-loop refreshes the read-only view whenever the writer's image mtime changes (polled every `Storage.EFS.ReplicaPollInterval`, default `1s`, after `Storage.EFS.ReplicaDebounceTicks` stable ticks, default `1`). How the refresh becomes visible depends on `Storage.EFS.ReplicaMode`:
  - **`overmount`** (default): native ext4. The driver over-mounts a freshly-attached RO ext4 image on top of its `MS_SHARED` anchor; the change propagates into the consumer through `mountPropagation: HostToContainer`. Metadata is resolved locally by the kernel (no per-syscall userspace hop) → fastest worker startup. Requires the direct-mount layout (see above).
  - **`fuse`**: FUSE pass-through. A userspace daemon serves the image and invalidates its root on refresh, so the next syscall sees the new state in place — no remount, no propagation needed (works even with subPath). Slower on metadata (every lookup/getattr crosses to userspace). Use as a fallback if over-mount misbehaves.

Tunables are exposed on the per-instance StorageClass; the chart wires them from `Storage.EFS.WriterSyncInterval`, `Storage.EFS.ReplicaPollInterval`, `Storage.EFS.ReplicaDebounceTicks`, `Storage.EFS.ReplicaMode`. Each image grows on demand via online CSI resize, starting from `Storage.EFS.SrcSize` (default `15Gi`, `odoo-src`) and `Storage.EFS.VenvSize` (default `5Gi`, `odoo-venv`).

**Pod roles & replicas**

- **Single mode** (`Instance.Pods=single`): `10-Odoo` is the writer (all containers). No `13-OdooReader` extras unless `Odoo.Replicas>0`.
- **Multi mode** (`Instance.Pods=multi`): `11-Cron` is the writer (cron + jupyter + cleaner + updater + alloy + log-merger + metrics — no HTTP, no `security`). `10-Odoo` is the base HTTP replica (which carries `security`).
- **Extra HTTP replicas** (`Odoo.Replicas>0`): each is its own Deployment (`odoo-replica-1`, `odoo-replica-2`, …) with a `replica-id` label. Paired 1-to-1 with `nginx-replica-N` via `podAffinity` required on `replica-id`. `K8S.ReplicaNode` controls their node group (defaults to `K8S.Node`).

**OEM `.manager` and `.ai` subPaths (all storage types)**

Since chart 1.1.12 the home layout is identical across `ebs`/`efs`/`fsx`: the base PVC is mounted as **subPath `odoo`** at `/home/odoo`, and OEM mounts two sibling subPaths of the **same** base PVC (on efs that PVC is the EFS Access Point `odoo-data-efs`, **not** csi-loop):

- **`.manager`** (`/home/odoo/.manager`) — only in the containers that read/write login-server tokens (`security` + `container-updater`). Holds OEM manager / login-server session tokens.
- **`.ai`** (`/home/odoo/.ai`) — only in the `ai` container (oem + staging). Holds each user's Claude/OpenCode credentials, transcripts and tmux socket.

Both are **not configurable** and deliberately mounted in only a *subset* of containers: the others don't even have the path visible, so a client with a shell in `jupyter` cannot read login-server tokens or the devs' AI credentials (structural isolation, stronger than file perms). On `efs` the Access Point enforces `uid:999/gid:999` kernel-level (chown returns `EPERM`, and NFS handles multi-writer concurrency cleanly); on `ebs`/`fsx` the subPath dir is created by kubelet — `ai-start` chowns `.ai` to `odoo`, while `.manager` stays root-owned for the root login-server. See `odoo.volumeMount.odooManager` / `odoo.volumeMount.odooAi`.

**Permissions**

The csi-loop images (`src`, `.venv`) come up root-owned (fresh ext4 root after `mkfs`); `fsGroup` only chowns a volume's own root, and these are two separate direct mounts. `system-prepare`'s `fix_perms()` step `chown odoo:odoo` on `/home/odoo/src` and `/home/odoo/.venv` before the runtime starts. `/home/odoo/.manager` is **not** chowned — the EFS Access Point enforces `uid:999/gid:999` kernel-level (chown returns `EPERM`). There is no separate `FixPermissions` initContainer any more.

**`--clone=1` semantics**

When the OEM clones a repo with `--clone=1`, `_refresh_git_dir()` deletes only `.git/` and re-inits with a shallow fetch + reset — the working tree (~1 GB) is preserved. Runs recursively across submodules. Orders of magnitude faster than a full byte-by-byte recopy.

**`system-prepare` runtime mode**

When `system-prepare` runs inside a runtime pod (rather than as the `init` Job) it detects that `/home/odoo/src` is already mounted by csi-loop, reuses the existing mount and skips any compaction step.

**Log aggregation**

Each odoo container writes its own logfile (`odoo.log` for writer, `odoo-replica-N.log` for replicas) in the EFS-shared `/home/odoo/logs/`. The `log-merger` sidecar in the writer pod tails the replica logfiles by inode and dual-writes them into the writer's `odoo.log`, so `tail -f /home/odoo/logs/odoo.log` shows writer + replicas merged in temporal order. Inode tracking + JSON checkpoint (`/home/odoo/logs/.log-merger-state.json`) survives logrotate cycles and pod restarts without losing or duplicating lines.

### `Storage.Type=fsx` (FSx for Lustre, shared multi-tenant)

`Storage.Type=fsx` binds a static PV to a **shared** FSx for Lustre filesystem identified by `Storage.FSX.Filesystem` + `Storage.FSX.MountName`. Multiple Odoo instances coexist on the same FSx isolated per-namespace via kubelet subPath (`subPath: {{ .Release.Namespace }}`). The PVC is named `odoo-data-fsx`. The PV's `dnsname` is auto-derived from `Storage.FSX.Filesystem` + `K8S.Region`. csi-loop is **not** used in this mode.

### MigrateStorage

`MigrateStorage=efs` is a one-shot trigger to migrate an existing instance from `Storage.Type=ebs` (or `fsx`) to `efs` without downtime of the current workloads.

When set, the chart additionally provisions the three EFS PVCs (`odoo-data-efs` + `odoo-src` + `odoo-venv`) and their StorageClasses alongside the current storage, plus a Job `migrate-storage-efs` (`28-MigrateStorage.yaml`) that rclones the data over.

Behaviour:
- Runs as `runAsUser: 0` but **not privileged** — csi-loop handles the loop image setup transparently, no `losetup` / `mkfs` in the Job itself.
- Steps inside the Job:
  1. `chown 999:999` on the csi-loop image roots `/mnt/new/src` + `/mnt/new/.venv` (fresh ext4, root-owned after `mkfs`).
  2. `rclone sync /mnt/old/ /mnt/new/` for top-level files **without** `--metadata` — the EFS Access Point enforces uid `999`/gid `999` kernel-level and chown returns `EPERM`. Mtimes are still preserved.
  3. `rclone sync /mnt/old/src/ /mnt/new/src/` **with** `--metadata` — destination is csi-loop ext4 which has full POSIX semantics.
  4. `rclone sync /mnt/old/.venv/ /mnt/new/.venv/` with `--metadata --copy-links` (dereferences `bin/python` → `/usr/bin/python3.12`, etc. — without `--copy-links` rclone skips venv symlinks and the venv ends up broken).
  5. OEM only: `rclone sync /mnt/old/.manager/ /mnt/new/.manager/` with `--metadata`.
- Co-located with the writer via `odoo.nodeSelector` (`podAffinity` required on label `node=<K8S.Node>`), so it shares the EBS RWO attachment with the running writer (multiple pods on the same node).
- Idempotent thanks to `rclone --check-first`. The Job intentionally has **no** `ttlSecondsAfterFinished` so it remains visible as a marker of a completed migration; to re-run, `kubectl delete job migrate-storage-efs` and resync.
- Hard precondition: `Storage.Type != efs`. Helm renders `{{ fail … }}` if both are set to `efs`.

Recommended flow:

```
1. Set MigrateStorage=efs, Storage.EFS.Filesystem=fs-xxxx (Storage.Type unchanged). ArgoCD sync.
2. Wait for Job migrate-storage-efs to reach status Complete.
3. kubectl exec into the Job pod and spot-check /mnt/new content.
4. Set Storage.Type=efs and MigrateStorage="". ArgoCD sync.
5. Runtime pods come back up over the new PVCs (odoo-data-efs + odoo-src).
```

## Node disruption (Karpenter)

Single-replica instances on **EFS/FSx** get a **zero-downtime node move** when Karpenter recycles their node (expiry / consolidation / drift) or on `kubectl drain` / cluster-autoscaler. Two pieces work together:

- **PDB** (`42-PodDisruptionBudget`, this chart) — `minAvailable=1` on the primary pods (`odoo`, `nginx`, + `cron` in multi). **Rendered only on EFS/FSx** (RWX, co-mountable); **never on EBS** (RWO can't surge). It is the **hold**: Karpenter's eviction is denied (429) and it waits.
- **Webhook** (`NodeChangeWebhook.DisruptionRollout` in the `odoo-env-manager` chart) — the **trigger**: the eviction attempt fires a `pods/eviction` MutatingWebhook that patches the Deployment (`restartedAt`) → RollingUpdate **surge** to a fresh node → old pod removed once the new is Ready → Karpenter completes the drain.

Net: 1 replica, brief surge to 2, **no downtime**. Detection of EFS/FSx is by the `odoo-base` PVC claim (`odoo-data-*`).

### Load balancer handoff (the third piece)

The PDB + webhook pair moves the **pod** without downtime, but on `Provider=eks` the **ALB** has its own view of which targets are alive, and it lags the cluster by a few seconds in both directions. Measured on 2026-08-01 while migrating the `celeritas01` node: 4 requests lost out of 1340 (99.70%), exactly one per tenant, each at the instant the old pod went away.

Everything that closes that gap comes from **one number**: the `odoo.nginx.lbLagSeconds` template constant in `templates/containers/_nginx.tpl`, currently **20 s**. That is the ALB's convergence time — health check interval 5 s × threshold 2 = 10 s minimum, plus registration propagation, measured on the real target group — and it is the same magnitude in both directions, because the ALB is equally late registering a new target and dropping one that is leaving. Three settings are derived from it:

| Derived | Value | Half |
|---|---|---|
| `minReadySeconds` (`12-Nginx`, `14-NginxReader`) | N = 20 s | entry |
| `preStop` sleep (nginx container) | N = 20 s | exit |
| `terminationGracePeriodSeconds` (both Deployments) | N + 5 = 25 s (**130 s** with `Instance.LongOp`, see below) | exit |

- **Entry** — with `maxUnavailable=0` the old pod is not retired until the new one has been `Ready` for `minReadySeconds`, i.e. until the ALB has had time to register the new target and health-check it.
- **Exit** — on delete, the kubelet's SIGTERM and the controller's target deregistration race each other; nginx would otherwise close instantly while the ALB still routes to it. The `preStop` sleep keeps it serving until the target leaves rotation.
- The **+5** on the grace period must always exceed the `preStop`: if the kubelet cut the `preStop` short with SIGKILL, the 502 would come straight back. Deriving it rather than setting it by hand is precisely so the two cannot drift apart. 5 s is enough for normal traffic — by the time the `preStop` expires the pod has been out of the Service endpoints for 20 s, so the only thing that can still be running is a request that started before the delete.
- **How the container actually dies matters here.** The image declares `STOPSIGNAL SIGQUIT` (checked in the `k8s-odoo/nginx` image config), so the kubelet does **not** send SIGTERM: it sends SIGQUIT, which in nginx is a *graceful* shutdown — the worker stays alive until it has drained whatever is in flight, and `worker_shutdown_timeout` is not set, so the only real bound is this grace period. For ordinary traffic that is invisible (nothing is in flight, the worker exits at once). It stops being invisible with the long-op chain, which is why `Instance.LongOp` gets a different budget.

Since 1.1.31 the grace period comes from the `odoo.nginx.terminationGraceSeconds` helper: `lbLag + 5` normally, and `lbLag + one long-op hop + 10` = **130 s** when `Instance.LongOp=true`. What the longer budget buys is **not** the client's answer — no number buys that, because the chain's state lives in that pod's RAM and the retry arrives as a fresh HTTP request that the Service routes to whichever pod is `Ready` (see [Long-op and nginx replicas](#long-op-and-nginx-replicas)). It buys **not cutting Odoo in half**: when the `preStop` expires, nginx may still hold a background call to `:8069` that can legitimately run for minutes (a module install, typically), and a 25 s grace SIGKILLed it 5 s after the SIGQUIT, aborting it at an arbitrary point. Because the shutdown is graceful, the pod still disappears as fast as ever when there is nothing in flight, so a routine rollout costs nothing; the worst case — a Karpenter drain waiting ~130 s for that pod — is paid only by tenants with the flag on. One hop (100 s, mirroring `INITIAL_TIMEOUT_MS` in the image's `longop.lua`) rather than the chain's 900 s cap: covering a whole operation would leave an nginx that cannot be drained for a quarter of an hour, and the piece that actually gets cut mid-write is the hop in flight.

The constant is deliberately **not** a value: it is not tuned per instance. The two halves were the `K8S.PodReadinessGate` and `K8S.NginxDrainSeconds` values until 1.1.27.

#### Why the ALB notices pod replacements at all

The Ingresses set `alb.ingress.kubernetes.io/target-type: ip` (`providers/_eks.tpl`), so the target group holds **pod IPs** and the ALB talks to the pod directly. The `nginx` Service is only the *discovery* mechanism the controller watches for EndpointSlices — it is not in the data path, and its `ClusterIP` would be unroutable from outside the cluster anyway: the service CIDR (`10.100.0.0/16`) is not a VPC CIDR, while pod IPs come from the VPC's secondary `100.64.0.0/16` and live on real ENIs. Replacing a pod therefore replaces the target, and the new one is registered and health-checked from scratch. Changing the Service `type` does not affect any of this.

`target-type: instance` would avoid the churn — node targets are stable — at the cost of an extra kube-proxy hop, NodePorts, **losing the client IP** (which Odoo and the login-server rely on through `X-Forwarded-For`), and health checks that no longer say anything about individual pods. Per-pod knowledge and registration stability are the same coin; this chart takes the first, and `lbLagSeconds` is what it costs.

#### Why not the ALB readiness gate

Up to 1.1.26 the entry side used the AWS LB controller's **pod readiness gate** (labelling the namespace `elbv2.k8s.aws/pod-readiness-gate-inject=enabled`). It is more precise — it waits for the real *healthy* signal instead of a fixed time — but it is **fail-closed**, and that is why it was dropped:

- If the controller does not reconcile, the pod stays `Running` and never becomes `Ready`, so it never enters the Service endpoints. nginx is serving fine inside and is invisible from everywhere.
- In a rolling update that only **stalls** the rollout (the old pod keeps serving), which is safe. But on a **cold start** — eviction, Karpenter consolidation, waking a suspended instance, a brand-new instance — there is no old pod, and nginx is effectively down.
- There is no way out without manual work: `spec.readinessGates` cannot be removed from a live pod, so you have to drop the namespace label, disable ArgoCD `selfHeal`, and recreate the pod.
- It also does not scale with custom domains. The controller injects **one gate per target group**, and every Ingress creates its own target group even when they all point at the same `nginx` Service — a tenant with five custom domains gets six gates, i.e. six independent fail-closed conditions guarding one pod.

With 170+ instances and nobody watching each one, losing the odd request in a hypothetical case beats hanging until a human intervenes. `minReadySeconds` fails **open**: if the ALB is slow, the pod is marked available anyway once the timer elapses, and the worst case is the 502 this section is about.

### WAF association

With `K8S.WafAclArn` set, the chart emits `alb.ingress.kubernetes.io/wafv2-acl-arn` on the `odoo` and `custom-domain-*` Ingresses, so the **AWS LB controller** attaches the Web ACL to the ALB it manages. (Not under CloudFront + Traefik: there is no ALB, and the Web ACL is attached to the CloudFront distribution — see [Ingress](#ingress).) It is a **group-level** annotation and both Ingresses share `group.name`, so they must emit the same value — hence a single `odoo.provider.eks.wafAnnotation` helper included by both. The Jupyter Ingress is deliberately excluded: different group (different ALB) and already restricted by `inbound-cidrs`.

Why bother, when Terraform can associate the Web ACL directly: Terraform associates by **ALB name**, so every ALB the controller creates when it shards (the 100-target-group limit) is born **without WAF** and nobody notices. Measured 2026-08-06: `public-clients-3` was serving 65 customer hostnames with no Web ACL while `public-clients` and `-2` had one. With the annotation the Web ACL follows the *Ingress group*, so any new ALB in the group inherits it.

> **Terraform's `aws_wafv2_web_acl_association` can stay.** Both paths converge on the same desired state as long as they name the **same** Web ACL, and the association is idempotent — the controller finds it already correct and does nothing. What breaks is *divergence*: if Terraform associates ACL X and the annotation says ACL Y, they overwrite each other in a loop. So the requirement is matching ARNs, not removing Terraform.
>
> Keep Terraform in place while rolling this out: the annotation only reaches an instance when kube_manager next patches it, so removing the Terraform association early would leave ALBs unprotected in the meantime. Dropping it afterwards is optional cleanup for a single source of truth.
>
> Measured 2026-08-06: **zero** `AssociateWebACL`/`DisassociateWebACL` events in 30 days with controller v2.8.1 and no annotations anywhere — v2.8.1 leaves existing associations alone when the annotation is absent. (PR #5 reported 17 disassociations in 14 days back in April; that is not happening now.)

### Suspended instances give up their slot

A node fills up on **pod slots** long before it fills up on CPU. Measured on 2026-07-29: three `staging01` nodes sat at **58/58 pods** — the ENI ceiling for an `r7g.xlarge` — with CPU around **20%**. There was no shortage of machine, only of slots. And because every pod ran at priority `0`, **nobody could evict anybody**: a DaemonSet or a real workload that needed to land simply stayed `Pending`.

Of the 150 `nginx` pods in that cluster, **26 belonged to suspended instances** (`Instance.Status=system_down`, serving nothing but the wake page), 25 of them on `staging01`.

`K8S.SleepingTenantPriorityClass` (default `oem-sleeping-tenant`, value `-10`) puts exactly those on a **negative** priority class, so the scheduler evicts them first instead of blocking real work. Two things make this the right lever rather than raising everyone else:

- Raising a pod that should stay only moves the problem to the next pod at `0`. Tried on 2026-07-29 with `promtail` → it evicted `s3-mounter`, another DaemonSet at `0`. The gap didn't close, it moved.
- The evicted pod here is a **normal pod, not a DaemonSet**, so its eviction also triggers Karpenter to add capacity — which is exactly what did *not* happen with `promtail`.

> ⚠️ **The PriorityClass is cluster-scoped, so it is NOT created by this chart** — 170+ releases cannot each own it, and pruning one Application would take it from the rest. Since `odoo-env-manager` **1.0.21** that chart creates it (`SleepingTenant.enabled=true`), being one release per cluster. Enable it in **exactly one** env-manager release per cluster. If the class does not exist in the target cluster, the pod is **rejected at admission**. Verify before rolling this chart into a new cluster:
> ```
> kubectl get priorityclass oem-sleeping-tenant
> ```
> Set `K8S.SleepingTenantPriorityClass: ""` to disable where it is not yet present. The older Terraform-created `sleeping-tenant` still exists in `odoo-clients` and `odoo-staging`; the new name was chosen so both can coexist and instances migrate as they are repinned.

**Requirements / caveats:**
- Both pieces must be on together: PDB alone = freeze (holds but never rotates); webhook alone = not zero-downtime (eviction wins before the surge).
- Karpenter must be able to provision a **replacement node matching the instance's `nodeSelector.service`**; otherwise the surge stays `Pending` (PDB just holds, no move).
- NodePool `terminationGracePeriod` should be **unset** so Karpenter waits on the PDB indefinitely (no force-kill).
- EBS keeps the existing behaviour (no PDB; an OEM node change goes through the `/mutate` webhook → `Recreate`).

## Networking

### Services

| Service | Type | Ports | Selector |
|---------|------|-------|----------|
| `odoo` | ClusterIP | 8069 (http) | single: `name: odoo` (writer + extras); multi: `name: odoo, role: replica` (cron pod is excluded) |
| `nginx` | ClusterIP | 8080 | `name: nginx` |
| `gevent` | ClusterIP | 8072 (longpolling/websocket) | `name: odoo` — every odoo container exposes 8072 |
| `security` | ClusterIP | 8081 (login-server) | `name: odoo` — security replicated in every odoo pod (sessions in EFS-shared so any can validate) |
| `jupyter` | ClusterIP | 8888 (jupyterlab), 8889 (opencode → `ai` container, oem+staging) | single: `name: odoo, role: writer`; multi: `name: cron, role: writer` (jupyter is single-instance, writer pod) |
| `monitoring` | ClusterIP | 9100 (alloy metrics) | single: `name: odoo`; multi: `name: cron, role: writer` |
| `memory-monitoring` | ClusterIP | 9191 (process RSS metrics) | `name: odoo` |
| `cron-memory-monitoring` | ClusterIP | 9191 (process RSS metrics, multi mode only) | `name: cron` (label `name: memory-monitoring` for ServiceMonitor discovery) |
| `pgbouncer` | ClusterIP | 5432 (optional, when `PgBouncer.enabled`) | `name: odoo` (all pods with the `odoo` container run their own local pool; `publishNotReadyAddresses: true`) |
| `postgres` | ExternalName -> `{{ Postgres.Host }}` | -- | -- |

On `Provider=eks` the `nginx` and `jupyter` Services also carry `alb.ingress.kubernetes.io/healthcheck-*` annotations (`providers/_eks.tpl`). They are read by the AWS LB controller when it builds the target group for the Ingress that points at the Service, so each block follows **its own** Ingress class and is omitted under CloudFront + Traefik — see [Ingress](#ingress). Note the `jupyter` block is inert for every OEM instance regardless of routing, since the `jupyter` Ingress is only rendered in self mode; that is pre-existing and deliberately left alone, because removing it would rewrite the manifests of ~150 tenants that are not migrating anywhere.

### NetworkPolicy (`instance-isolation`)

Egress + Ingress policy:

**Egress**:
- **Allow**: same namespace (nginx, odoo, login-server inter-pod)
- **Allow**: `kube-system` (DNS only, ports 53 UDP/TCP)
- **Allow**: `odoo-env-manager` pod `monitoring` (Grafana for `/_odoo/dashboard`)
- **Allow**: `odoo-env-manager` pod `argo-gateway` (ArgoCD status reporting)
- **Allow**: internet (excluding RFC1918 as defense in depth — does not reliably block ClusterIP Service traffic)
- **Staging only**: access to production namespace of same customer (`oem/customer-id` + `oem/stage` labels)

**Ingress**:
- **Allow**: same namespace
- **Allow**: from `monitoring` namespace (Prometheus scraping Alloy metrics)
- **Allow**: from `odoo-env-manager` namespace (KubeManager exec into pods)
- **Allow**: port 8080 from any source (ALB traffic to nginx)

Note: `ipBlock.except` on egress does not block traffic via ClusterIP Services (kube-proxy DNAT bypass). The Ingress policy with `namespaceSelector` provides the real cross-namespace isolation.

### Ingress

- **Class**: `ingressClassName: {{ Ingress.Odoo.Type }}` (provider-specific ingress controller)
- **Host**: `{{ Odoo.Subdomain | default <namespace> }}.{{ Cluster.Domain }}`. In self mode a second `jupyter` Ingress is also rendered at `…internal.{{ Cluster.Domain }}`.
- **TLS**: the main `odoo` Ingress serves TLS through the ALB via ACM hostname auto-discovery (a `tls.hosts` block + the `alb.ingress.kubernetes.io/*` annotations; no cert-manager annotation). cert-manager Let's Encrypt (`aws-letsencrypt-{{ Ingress.Odoo.Name }}` ClusterIssuer) is used only for the per-domain `Certificate` objects in `18-Certificates`.
- **Custom domains**: one Ingress per entry in `Odoo.CustomDomains` (`17-CustomIngress`). TLS binds via explicit `alb certificate-arn` once OEM knows the ARN (ACM hostname auto-discovery meanwhile). **Manual** certs are materialised once per certificate as a shared tls Secret in the production namespace (`Odoo.Certificates`, `18-Certificates`) — aws-cert-manager imports it to ACM and kube_manager reports the ARN back to OEM, so **one cert can cover N domains across instances**. **Auto** domains get a per-domain cert-manager `Certificate` (Let's Encrypt).
- **CloudFront + Traefik routing** (`K8S.Provider=eks` **and** `Ingress.Odoo.Type=traefik`, chart ≥ 1.1.30): the `odoo` and `custom-domain-*` Ingresses drop **all** `alb.ingress.kubernetes.io/*` annotations (including `wafv2-acl-arn` and `certificate-arn`) and their `tls:` block. Since 1.1.31 the **`nginx` Service** drops its three `alb.ingress.kubernetes.io/healthcheck-*` annotations too: those configure the target group the AWS LB controller builds for the Ingress, and under Traefik there is no target group — what decides whether the backend is alive is the pod's `readinessProbe`, since Traefik only routes to `Ready` endpoints. The `jupyter` Service is gated on **its own** class (`Ingress.Jupyter.Type`, helper `odoo.ingress.cloudfrontTraefik.jupyter`), because its Ingress lives on a different ALB and moving `odoo` to Traefik says nothing about it. None of it applies — TLS and WAF live at the CloudFront edge and Traefik receives plain HTTP from the internal NLB — and leaving it in place both documents a load balancer this tenant no longer uses and would hand Traefik a list of hostnames to serve with its self-signed default cert the day a `websecure` entrypoint is added. Everything else (class, rules, backend) is unchanged, and the `alb` path renders byte-for-byte as before. The helper is `odoo.ingress.cloudfrontTraefik` in `providers/_common.tpl`; the provider is part of the test on purpose, since **hetzner** also uses Traefik but does terminate TLS there.
- **The HTTP→HTTPS redirect is not lost with `ssl-redirect`, and must not be re-added in Traefik.** Dropping the `alb.*` annotations drops `alb.ingress.kubernetes.io/ssl-redirect: "443"` with them; the redirect moves to the CloudFront edge, which is strictly earlier in the path. Verified 2026-08-07 on distribution `E2GB5XLTPY67MW`: `DefaultCacheBehavior.ViewerProtocolPolicy = redirect-to-https`, **0** extra cache behaviors (so it covers every path), and neither distribution tenant carries a `Customizations` block that could override it — only `Certificate`. **Adding a Traefik redirect middleware would be a bug, not a belt-and-braces**: CloudFront always reaches the origin over **plain HTTP** through the VPC Origin, so a redirect on the `web` entrypoint would fire on *every* request and bounce the client in a loop. The chart therefore adds nothing here. What to re-check before assuming it still holds: a new cache behavior with `allow-all`, or a per-tenant `Customizations` that changes the viewer protocol policy.

## ArgoCD Status Reporting

OEM scripts (`system-prepare`, `odoo-migrate`, `restore-backup`) report build/migration/restore status to ArgoCD Application annotations via the **ArgoGateway HTTP API**. No ServiceAccount, ClusterRole, or projected token is needed — all ArgoCD access goes through `ARGOCD_GATEWAY_URL` (env var injected by KubeManager into each instance).

## Monitoring

- **ServiceMonitor** `odoo-metrics`: scrapes `monitoring` service (alloy :9100) every 5s — log and system metrics
- **ServiceMonitor** `odoo-memory-metrics`: scrapes `memory-monitoring` service (metrics-server :9191) every 5s — per-process RSS
- **Grafana dashboard**: ConfigMap with `grafana_dashboard=1` + `grafana_public_dashboard=1` labels — auto-provisioned by Grafana sidecar and published by `grafana-public-dashboard` controller. Dashboard uid: `sha256sum | trunc 40` of namespace (Grafana uid max 40 chars)
  - **CPU metrics panels** (id 86-87): `sum by (replica_id, worker_id)(rate(odoo_worker_cpu_seconds_total[1m]))` — per-worker CPU usage (grouping by `worker_id` avoids duplicate series per PID restart; `replica_id` splits per reader pod), placed above RAM panels
  - **Node Resources row**: Conditional on `K8S.NodeType=="dedicated"` — % CPU Node, % RAM Node panels. Hidden for shared nodes.
  - **Workers section** (id 90-95): "HTTP concurrency & queue" (panel 91: "Concurrency (estimated)" = `rate(odoo_http_time1_seconds_total[1m]) + rate(odoo_http_time2_seconds_total[1m])` and "Queued (waiting)" = `max by (namespace)(odoo_http_queue)` — `odoo_http_connections` is used only by panels 93-95), "% HTTP semaphore usage" (panel 92: `odoo_http_time1_seconds_total + odoo_http_time2_seconds_total / (MaxHTTPThreads * Workers) * 100`), "Workers recommended" (now/peak 1h/peak 24h) — 3 combined stat panels, each showing CPU / Connections / Total (max of both). CPU formula: `ceil(sum(rate(odoo_worker_cpu_seconds_total)) / 0.80)`. Connections formula: `ceil((connections + queue) / MaxHTTPThreads)`. Peak panels use `max_over_time` on raw gauge for connections (captures short spikes). Dynamic threshold via `configFromData` transformation: Query D returns `count(odoo_worker_pid{worker_id=~"Worker.*"})` as table/instant, colors green when recommended <= current workers, red when exceeded. See [workers-recommendation.svg](docs/workers-recommendation.svg) for diagram.
- **Central dashboard**: `odoo_thanos_central.json` — multi-instance version with `$namespace`, `$node` (auto-derived from pod placement), `$workers` (auto-derived from `odoo_worker_pid` count), and `$max_http_threads` selector variables. Same panels and formulas as per-instance dashboard but with Grafana variables instead of Helm values.

## Nginx Error Pages

Custom error pages (401, 500, 502) include the ProcessControl logo (base64 inline) and a timestamp with timezone. The 502 page text is tailored for maintenance messaging.

In self mode, a `/_odoo/redirect` location is added to the nginx config for login redirects, with `proxy_intercept_errors on` to handle error-based redirect flows.

## Long-op signing key

`Instance.LongOp=true` makes nginx wrap slow POSTs in a 303 chain so they survive CloudFront's 120 s origin read timeout (needs the nginx image ≥ 1.1.3: 1.1.2 shipped the X-Forwarded-Host injection and the 16M body buffer). The chain's UUIDs are signed with `LONGOP_SECRET`, injected into the nginx container by `secretKeyRef`/`configMapKeyRef` — **never interpolated**, because the value is re-randomised on every render and only ArgoCD's `ignoreDifferences` on `/data` + `/stringData` of `odoo-secrets` keeps it stable in the cluster; interpolating it would produce a different env on every sync and restart nginx forever.

Since 1.1.30 it is **its own key** in `odoo-secrets`. Before that it was the tenant's `PGPASSWORD` — the same value as the Aurora credential — which meant rotating the database password silently killed every in-flight long operation (kubelet does not propagate `secretKeyRef` env, so nginx has to restart to pick a new value up) and anything able to read the Secret got both secrets at once. Two purposes, two keys.

> ⚠️ **Enabling `LongOp` on an instance created before 1.1.30**: ArgoCD ignores `/data` and `/stringData` of `odoo-secrets`, so it will **not** add the new key to a Secret that already exists. Materialise it once (e.g. `kubectl -n <ns> patch secret odoo-secrets --type=merge -p '{"stringData":{"LONGOP_SECRET":"<32 random chars>"}}'`) before flipping the flag, or the nginx container will not start.

## Long-op and nginx replicas

**`Instance.LongOp=true` requires exactly one nginx pod per tenant, and since 1.1.31 the chart refuses to render `Instance.LongOp=true` together with `Odoo.Replicas>0`** (`odoo.nginx.longOpGuard` in `containers/_nginx.tpl`, reached from every template that builds an nginx pod).

The chain's state lives in `lua_shared_dict longop_state`, i.e. one worker's memory. The 303 makes the client come back as a **new HTTP request**, and the `nginx` Service selects on `name: nginx` with **no `sessionAffinity`**, so it spreads those retries over every pod carrying that label — and `14-NginxReader` creates one `nginx-replica-N` Deployment per `Odoo.Replicas` with exactly that label. With replicas the retry therefore hits the right pod roughly 1 time in N+1 and returns 502 the rest, intermittently, with nothing in the logs pointing at the cause. Neither the HMAC nor DNS saves it: `LONGOP_SECRET` is the same in every pod of the tenant, and CloudFront has no session affinity (the ALB did have per-target-group stickiness).

Notes on the guard:

- It is a hard `fail`, not a warning, because Helm has no warnings and the failure mode it prevents is *intermittently wrong answers*, not a crash. Verified on 2026-08-07 that it breaks no existing render: `Instance.LongOp` defaults to `false` and the only instance in the fleet with `LONGOP_ENABLED` is `processcontrol-build-00000999`, with `Replicas=0`.
- It also fires on `Storage.Type=ebs`, where `14-NginxReader` is skipped and the combination is harmless *today*: a `MigrateStorage` to `efs` would otherwise turn a tenant that renders fine into a broken one, silently.
- The real fixes are externalising the chain state, or session affinity in Traefik for the `/__longop_retry/` prefix. Until one of them exists, the combination is rejected at render time instead of in production.
- A rollout of the single nginx pod still loses the operations it was holding — see the grace-period discussion in [Load balancer handoff](#load-balancer-handoff-the-third-piece). The image answers those retries with a clean 502 (the shutdown path marks the record) instead of hanging until the 900 s cap.

## RDS master credentials from AWS (External Secrets)

`Postgres.MasterSecret.Name` (and `Source.MasterSecret.Name` for the clone source) is the name of the Secrets Manager secret holding the RDS master `{username, password}`. When set:

- `02-Secrets.yaml` stops rendering `PGMASTERUSER`/`PGMASTERPASSWORD` (`PGSOURCE*`) in `odoo-admin-secrets`, and `Postgres.MasterUser/MasterPassword` are not used.
- `02-MasterExternalSecret.yaml` renders an `ExternalSecret` (`creationPolicy: Merge`, sync-wave 1) that fills those keys from AWS. It needs the ESO `ClusterSecretStore` named by `ExternalSecrets.Store` and an IAM role able to read the secret.
- The Application **must** carry an `ignoreDifferences` on `/data/PGMASTERUSER` and `/data/PGMASTERPASSWORD` (`/data/PGSOURCE*`) of `odoo-admin-secrets`, plus `RespectIgnoreDifferences=true`, or ArgoCD prunes them. kube_manager adds it only in this mode: with it on in password mode a changed password would never be applied.
- `22-CleanData.yaml` renders its own hook `ExternalSecret` in `default`: the post-delete Job runs after the tenant namespace is gone, so it cannot read `odoo-admin-secrets`.

`ExternalSecrets.RefreshInterval` (default `5m`) bounds how long a rotation in AWS takes to reach the Secret.

- **Jobs** (`system-prepare`, `final-backup`, migrations, rebuild, restore) read the credentials from `envFrom` at start, so they carry sync-wave 2: ArgoCD applies the ExternalSecret (wave 1, health "Secret was synced") first. At wave 0 it would wait for the Job and never apply the ExternalSecret.
- **`container-updater`** is long-lived and its environment is frozen at start, so the Secret is also mounted there as files (`/run/secrets/odoo-admin`, no `subPath`: kubelet only refreshes whole-directory mounts). The image (≥ 1.0.57) reads the credentials from those files when it uses them (`odoo_tools.credential`) and falls back to the environment. A rotation reaches it after the refresh interval plus ~1 min, with no restart. An older image ignores the mount.

## Cleanup

On `helm uninstall`, the post-delete hook Job `clean-data-{{ namespace }}` runs in the `default` namespace:
- Executes `system-prepare --clean=1`
- Drops the database user and cleans up files
- TTL: 60s after completion

## Values Reference

### Required

| Value | Description |
|-------|-------------|
| `Instance.Controller` | Controller mode: `"self"` (standalone) or `"oem"` (centrally managed) |
| `Instance.Pods` | Pod topology: `"single"` (all in one pod) or `"multi"` (split across pods) |
| `Customer.Name` | Customer identifier |
| `Customer.ID` | Unique customer ID |
| `Cluster.Domain` | Base domain (e.g., `example.com`) |
| `K8S.Provider` | Kubernetes provider identifier (e.g., `aws`, `gke`, `aks`). Replaces former `AWS.*` prefix. |
| `K8S.Region` | Provider region (e.g., `eu-west-3`) |
| `K8S.Bucket` | Object-storage bucket for backups |
| `K8S.Node` | Node affinity label |
| `Postgres.Host` | PostgreSQL host |
| `Postgres.MasterUser` | DB admin user (base64) |
| `Postgres.MasterPassword` | DB admin password (base64) |
| `Postgres.MasterSecret.Name` | AWS secret with the master credentials; replaces the two above (see [RDS master credentials](#rds-master-credentials-from-aws-external-secrets)) |
| `Odoo.Version` | Odoo version (e.g., `18.0`) |
| `Odoo.Stage` | `production` or `staging` |
| `Odoo.OdooRevision` | Odoo core git revision |
| `Odoo.EnterpriseRevision` | Enterprise git revision |
| `Odoo.ThemesRevision` | Design themes git revision |
| `Git.Repository` | Customer repository URL |
| `Git.Branch` | Git branch |
| `Git.Commit` | Git commit SHA |
| `Git.Keys` | SSH private keys as YAML string (parsed via `fromYaml` in templates). Pass via `--set Git.Keys=...` with YAML-encoded key-value pairs (e.g., `id_rsa: <base64-key>`). Supports multiple keys for submodule repos. |

### Optional

| Value | Default | Description |
|-------|---------|-------------|
| `Instance.Status` | `init` | Lifecycle state |
| `Instance.Active` | `true` | Self-mode kill-switch: when `false` all workloads (system-prepare, odoo, cron, ingress, ServiceContainer, nginx) are skipped. Ignored in OEM mode (status drives everything). |
| `Instance.IdleSuspend` | `360` | OEM stagings only: scale odoo/cron to zero after N idle minutes (`0` = disabled). nginx flips `Instance.Status` `run`↔`system_down` via `ArgoGateway`. |
| `Instance.LongOp` | `false` | nginx long-op chain: wraps slow POSTs in a 303 loop so they survive CloudFront's 120 s origin read timeout. Requires the nginx image ≥ 1.1.3 (1.1.2 shipped the X-Forwarded-Host injection and the 16M body buffer) and the `LONGOP_SECRET` key in `odoo-secrets` — see [Long-op signing key](#long-op-signing-key) for the caveat on instances created before chart 1.1.30. **Mutually exclusive with `Odoo.Replicas>0`** (hard `fail`) and it raises the nginx grace period to 130 s — see [Long-op and nginx replicas](#long-op-and-nginx-replicas). |
| `Customer.DisplayName` | `""` | Real customer name, base64-encoded (set by kube_manager). Used as `CUSTOMER_NAME`; falls back to the anonymized `Customer.Name` when empty. |
| `Labels` | `""` | Extra K8S labels applied to every instance resource — a YAML map serialised by OEM (like `Git.Keys`). Empty = no extra labels. |
| `Odoo.MemoryWatchdog` | `true` | RAM watchdog (Odoo.sh style): kills the highest-RSS worker under container memory pressure instead of letting K8S OOM-kill the pod. Exposed as `MEMORY_WATCHDOG`. On by default since chart 1.1.27. |
| `Snapshots.Type` | `"k8s"` | Snapshot backend. `k8s` = CSI VolumeSnapshots via snapscheduler (EBS only). See [EBS Snapshots](#ebs-snapshots-production-only). |
| `Odoo.Replicas` | `0` | Number of **additional** HTTP reader pods (`13-OdooReader-1..N`) on top of the always-on base. Only takes effect with `Storage.Type=efs` or `fsx` (RWX needed for the shared `/home/odoo`). With `ebs` (RWO) the extras are skipped. Each replica also brings its own nginx (`14-NginxReader`) behind the shared `nginx` Service, which is why it cannot be combined with `Instance.LongOp` — see [Long-op and nginx replicas](#long-op-and-nginx-replicas). |
| `Odoo.ReaderSyncInterval` | `5` | **DEPRECATED**: kept for chart compatibility; ignored at runtime. Replica freshness is now handled by the csi-loop driver's mtime polling — see `Storage.EFS.ReplicaPollInterval`. |
| `K8S.ReplicaNode` | `null` | Node group for the extra reader Deployments (`13-OdooReader`, `14-NginxReader`). Falls back to `K8S.Node` when empty. |
| `K8S.SleepingTenantPriorityClass` | `"oem-sleeping-tenant"` | PriorityClass for the `nginx` of a **suspended** instance (`Instance.Status=system_down`), which only serves the wake page. Negative priority (`-10`) makes it the first thing evicted when a node runs out of pod slots. **Created by the `odoo-env-manager` chart (≥1.0.21), not by this one** — it is cluster-scoped. Set to `""` in clusters where it does not exist yet, or pods are rejected at admission. See [Suspended instances give up their slot](#suspended-instances-give-up-their-slot). |
| `K8S.WafAclArn` | `null` | WAFv2 Web ACL ARN for the Odoo ALB. When set (and `K8S.Provider=eks`, and `Ingress.Odoo.Type` is not `traefik`), the chart adds `alb.ingress.kubernetes.io/wafv2-acl-arn` to the `odoo` and `custom-domain-*` Ingresses so the **AWS LB controller** attaches the Web ACL itself. `null`/empty = annotation not emitted. Sent per-cluster by kube_manager from `WAF_ACL_ARN` (`KubeManager.WafAclArn` in the `odoo-env-manager` chart). See [WAF association](#waf-association). |
| `Odoo.Workers` | `1` | Odoo HTTP workers |
| `Odoo.Cron` | `1` | Cron threads |
| `Odoo.MemoryLimitHard` | `2415919104` | ~2.25 GB (set by OEM based on performance_profile) |
| `Odoo.MemoryLimitSoft` | `2147483648` | ~2 GB (80% of hard limit, set by OEM) |
| `Odoo.CPULimit` | `720` | Odoo CPU time limit per request (s) |
| `Odoo.RealLimit` | `900` | Real time limit (s) |
| `Odoo.Subdomain` | namespace | Ingress subdomain |
| `Odoo.CustomDomains` | — | List of custom domains with TLS certs |
| `Odoo.AllowedHosts` | `[]` | JSON IP whitelist |
| `Odoo.ImageBranch` | — | Image tag suffix |
| `Postgres.Version` | `17` | PostgreSQL client version |
| `Storage.Type` | `"ebs"` | Storage backend: `"ebs"` (per-instance EBS RWO + separate `odoo-data` in self), `"fsx"` (shared FSx Lustre, RWX, per-namespace subPath), `"efs"` (EFS Access Point RWX + csi-loop for `src`/`.venv`) |
| `Storage.Base` | `6Gi` | Base PVC size |
| `Storage.Data` | `4Gi` | Data PVC size (self only, EBS only) |
| `Storage.EFS.Filesystem` | `null` | EFS filesystem ID (e.g. `fs-005f9a3d290e6c025`). **Required** when `Storage.Type=efs` or `MigrateStorage=efs`. |
| `Storage.EFS.SrcSize` | `15Gi` | Initial size of the csi-loop image PVC `odoo-src` (`/home/odoo/src`). Grows on demand via CSI online resize. |
| `Storage.EFS.VenvSize` | `5Gi` | Initial size of the csi-loop image PVC `odoo-venv` (`/home/odoo/.venv`). Grows on demand via CSI online resize. |
| `Storage.EFS.WriterSyncInterval` | `1s` | csi-loop writer page-cache flush interval (StorageClass tunable). |
| `Storage.EFS.ReplicaPollInterval` | `1s` | csi-loop replica mtime poll interval (StorageClass tunable). |
| `Storage.EFS.ReplicaDebounceTicks` | `1` | csi-loop number of stable poll ticks before the replica refreshes its view (StorageClass tunable). |
| `Storage.EFS.ReplicaMode` | `overmount` | csi-loop replica refresh mechanism (StorageClass tunable). `overmount` = native ext4 over-mount (fast metadata; needs the direct-mount layout + `mountPropagation: HostToContainer`). `fuse` = FUSE pass-through fallback (subPath-compatible, slower metadata). |
| `Storage.FSX.Filesystem` | `null` | FSx for Lustre filesystem ID (e.g. `fs-0a1b2c3d4e5f6a7b8`). **Required** when `Storage.Type=fsx`. |
| `Storage.FSX.MountName` | `null` | FSx for Lustre mount name (4-8 char alphanumeric, shown in the AWS console / `aws fsx describe-file-systems`). **Required** when `Storage.Type=fsx`. |
| `MigrateStorage` | `""` | One-shot storage migration trigger. Valid: `""` (default) or `"efs"`. When `efs`, the chart provisions the EFS+csi-loop PVCs and a `migrate-storage-efs` Job alongside the current storage. See [MigrateStorage](#migratestorage). Helm fails if both `MigrateStorage=efs` and `Storage.Type=efs`. |
| `Resources.Odoo.RequestCPU` | — | CPU request for odoo container (computed by OEM) |
| `Resources.Odoo.LimitCPU` | — | CPU limit for odoo container (OEM: workers * 1000m) |
| `Resources.Odoo.RequestRAM` | — | RAM request for odoo container (computed by OEM) |
| `Resources.Odoo.LimitRAM` | — | RAM limit for odoo container (computed by OEM) |
| `Resources.Cron.RequestCPU` | — | CPU request for cron container (computed by OEM) |
| `Resources.Cron.LimitCPU` | — | CPU limit for cron container (OEM: 1000m fixed) |
| `Resources.Cron.RequestRAM` | — | RAM request for cron container (computed by OEM) |
| `Resources.Cron.LimitRAM` | — | RAM limit for cron container (computed by OEM) |
| `Odoo.MaxDBConn` | `"64"` | PostgreSQL max connections per Odoo process (`--db_maxconn`) |
| `Odoo.MaxHTTPThreads` | `"32"` | Odoo internal HTTP thread pool limit |
| `K8S.NodeType` | `"shared"` | Node type: `"shared"` or `"dedicated"`. When dedicated, Node resources row + panels are rendered in Grafana dashboard |
| `PgBouncer.enabled` | `false` | Enable PgBouncer sidecar for connection pooling (transaction mode) |
| `PgBouncer.PoolPercent` | `"25"` | Pool size as percentage of MaxClientConn |
| `PgBouncer.Image` | — | Custom PgBouncer Docker image (Alpine + pgbouncer + su-exec) |
| `Source.Name` | — | Source instance (staging rebuild/migration) |
| `Upgrade.Version` | — | Target Odoo version for migration |
| `Restore.Backup` | — | Backup filename to restore |

### Images

Images are now configured under the `Images` key with per-image `Image` (registry/repo) and `Branch`/`Version` fields:

| Value | Description | Default |
|-------|-------------|---------|
| `Images.Odoo.Image` | Odoo container image | `916273940701.dkr.ecr.eu-west-3.amazonaws.com/k8s-odoo/odoo` |
| `Images.Odoo.Version` | Odoo image version tag (final tag is `{Odoo.Version}-{Images.Odoo.Version}[-{Branch}]`, e.g. `18.0-1.0.0`) | `1.0.0` |
| `Images.Odoo.Branch` | Odoo image tag suffix | -- |
| `Images.Nginx.Image` | Nginx container image | `916273940701.dkr.ecr.eu-west-3.amazonaws.com/k8s-odoo/nginx` |
| `Images.Nginx.Branch` | Nginx image tag suffix | -- |
| `Images.Nginx.Version` | Nginx image version tag | `1.0.0` |
| `Images.Alloy.Image` | Alloy container image | `916273940701.dkr.ecr.eu-west-3.amazonaws.com/k8s-odoo/alloy` |
| `Images.Alloy.Branch` | Alloy image tag suffix | -- |
| `Images.Alloy.Version` | Alloy image version tag | `1.0.1` |
| `Images.Credentials.User` / `.Password` / `.Host` | Private registry pull credentials (used to build the `registry-credentials` pull secret) | -- |
